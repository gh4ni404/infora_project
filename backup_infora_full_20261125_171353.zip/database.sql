-- ========================================================
-- INFORA PLATFORM - DATABASE BACKUP DUMP
-- Tanggal Pembuatan : 25 November 2026 17:13:53
-- Basis Data       : smknbone_infora_development
-- Driver           : mysql
-- ========================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+00:00';
SET NAMES utf8mb4;

-- --------------------------------------------------------
-- Struktur Tabel untuk `absensi_murids`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `absensi_murids`;
CREATE TABLE `absensi_murids` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `murid_id` bigint unsigned NOT NULL,
  `kelas_id` bigint unsigned DEFAULT NULL,
  `tahun_ajaran_id` bigint unsigned DEFAULT NULL,
  `semester_id` bigint unsigned DEFAULT NULL,
  `face_profile_id` bigint unsigned DEFAULT NULL,
  `tanggal` date NOT NULL,
  `jam_masuk` timestamp NULL DEFAULT NULL,
  `jam_pulang` timestamp NULL DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hadir',
  `metode` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'face_recognition',
  `match_score` decimal(5,4) DEFAULT NULL,
  `foto_masuk_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_pulang_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `absensi_murids_school_murid_date_unique` (`school_id`,`murid_id`,`tanggal`),
  KEY `absensi_murids_murid_id_foreign` (`murid_id`),
  KEY `absensi_murids_kelas_id_foreign` (`kelas_id`),
  KEY `absensi_murids_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  KEY `absensi_murids_semester_id_foreign` (`semester_id`),
  KEY `absensi_murids_face_profile_id_foreign` (`face_profile_id`),
  KEY `absensi_murids_recorded_by_foreign` (`recorded_by`),
  KEY `absensi_murids_school_date_status_idx` (`school_id`,`tanggal`,`status`),
  KEY `absensi_murids_tanggal_index` (`tanggal`),
  KEY `absensi_murids_status_index` (`status`),
  CONSTRAINT `absensi_murids_face_profile_id_foreign` FOREIGN KEY (`face_profile_id`) REFERENCES `murid_face_profiles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `absensi_murids_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `absensi_murids_murid_id_foreign` FOREIGN KEY (`murid_id`) REFERENCES `murids` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absensi_murids_recorded_by_foreign` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `absensi_murids_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absensi_murids_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`) ON DELETE SET NULL,
  CONSTRAINT `absensi_murids_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajaran` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `absensi_murids`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `cache`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `cache`
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('infora-cache-infora_active_modules_tree_v1', 's:58396:\"O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:7:{i:0;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:1;s:4:\"name\";s:14:\"NAVIGASI UTAMA\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:13\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:1;s:4:\"name\";s:14:\"NAVIGASI UTAMA\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:13\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:2:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:1;s:9:\"module_id\";i:1;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:9:\"dashboard\";s:4:\"icon\";s:9:\"dashboard\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-23 11:42:23\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:1;s:9:\"module_id\";i:1;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:9:\"dashboard\";s:4:\"icon\";s:9:\"dashboard\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-23 11:42:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:5;s:9:\"module_id\";i:1;s:4:\"name\";s:12:\"Media Publik\";s:10:\"route_name\";s:2:\"tv\";s:4:\"icon\";s:5:\"globe\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:48:40\";s:10:\"updated_at\";s:19:\"2026-09-14 18:48:40\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:5;s:9:\"module_id\";i:1;s:4:\"name\";s:12:\"Media Publik\";s:10:\"route_name\";s:2:\"tv\";s:4:\"icon\";s:5:\"globe\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:48:40\";s:10:\"updated_at\";s:19:\"2026-09-14 18:48:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:5;s:4:\"name\";s:13:\"HALAMAN ADMIN\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:56:29\";s:10:\"updated_at\";s:19:\"2026-09-27 09:10:10\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:5;s:4:\"name\";s:13:\"HALAMAN ADMIN\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:56:29\";s:10:\"updated_at\";s:19:\"2026-09-27 09:10:10\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:11;s:9:\"module_id\";i:5;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:15:\"dashboard.admin\";s:4:\"icon\";s:6:\"school\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:58:28\";s:10:\"updated_at\";s:19:\"2026-09-27 08:59:31\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:11;s:9:\"module_id\";i:5;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:15:\"dashboard.admin\";s:4:\"icon\";s:6:\"school\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:58:28\";s:10:\"updated_at\";s:19:\"2026-09-27 08:59:31\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:6;s:4:\"name\";s:11:\"HALAMAN GTK\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:06:40\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:6;s:4:\"name\";s:11:\"HALAMAN GTK\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:06:40\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:12;s:9:\"module_id\";i:6;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:13:\"dashboard.gtk\";s:4:\"icon\";s:9:\"briefcase\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:07:16\";s:10:\"updated_at\";s:19:\"2026-10-19 20:23:26\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:12;s:9:\"module_id\";i:6;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:13:\"dashboard.gtk\";s:4:\"icon\";s:9:\"briefcase\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:07:16\";s:10:\"updated_at\";s:19:\"2026-10-19 20:23:26\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"ADMINISTRASI\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:15:41\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"ADMINISTRASI\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:15:41\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:4:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:3;s:9:\"module_id\";i:3;s:4:\"name\";s:6:\"Master\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"database\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:16:32\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:54\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:3;s:9:\"module_id\";i:3;s:4:\"name\";s:6:\"Master\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"database\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:16:32\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:54\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:6:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:5;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Sekolah\";s:10:\"route_name\";s:19:\"master.data-sekolah\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:18:26\";s:10:\"updated_at\";s:19:\"2026-09-08 02:18:26\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:5;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Sekolah\";s:10:\"route_name\";s:19:\"master.data-sekolah\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:18:26\";s:10:\"updated_at\";s:19:\"2026-09-08 02:18:26\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:7:\"menu_id\";i:3;s:4:\"name\";s:14:\"Data Tingkatan\";s:10:\"route_name\";s:21:\"master.data-tingkatan\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:40:56\";s:10:\"updated_at\";s:19:\"2026-09-15 00:10:44\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:7:\"menu_id\";i:3;s:4:\"name\";s:14:\"Data Tingkatan\";s:10:\"route_name\";s:21:\"master.data-tingkatan\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:40:56\";s:10:\"updated_at\";s:19:\"2026-09-15 00:10:44\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Jurusan\";s:10:\"route_name\";s:19:\"master.data-jurusan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:41:33\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:08\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Jurusan\";s:10:\"route_name\";s:19:\"master.data-jurusan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:41:33\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:08\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:7:\"menu_id\";i:3;s:4:\"name\";s:19:\"Data Mata Pelajaran\";s:10:\"route_name\";s:17:\"master.data-mapel\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:39:08\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:25\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:7:\"menu_id\";i:3;s:4:\"name\";s:19:\"Data Mata Pelajaran\";s:10:\"route_name\";s:17:\"master.data-mapel\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:39:08\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:25\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:7:\"menu_id\";i:3;s:4:\"name\";s:28:\"Data Pendidik & Tendik (gtk)\";s:10:\"route_name\";s:15:\"master.data-gtk\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:05:21\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:37\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:7:\"menu_id\";i:3;s:4:\"name\";s:28:\"Data Pendidik & Tendik (gtk)\";s:10:\"route_name\";s:15:\"master.data-gtk\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:05:21\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:37\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:5;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:7:\"menu_id\";i:3;s:4:\"name\";s:10:\"Data Murid\";s:10:\"route_name\";s:17:\"master.data-murid\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:07:10\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:46\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:7:\"menu_id\";i:3;s:4:\"name\";s:10:\"Data Murid\";s:10:\"route_name\";s:17:\"master.data-murid\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:07:10\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:46\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:6;s:9:\"module_id\";i:3;s:4:\"name\";s:18:\"Rombel & Bimbingan\";s:10:\"route_name\";N;s:4:\"icon\";s:14:\"graduation-cap\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:52:26\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:26\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:6;s:9:\"module_id\";i:3;s:4:\"name\";s:18:\"Rombel & Bimbingan\";s:10:\"route_name\";N;s:4:\"icon\";s:14:\"graduation-cap\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:52:26\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:26\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:7:\"menu_id\";i:6;s:4:\"name\";s:10:\"Data Kelas\";s:10:\"route_name\";s:12:\"rombel.kelas\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:42:03\";s:10:\"updated_at\";s:19:\"2026-09-14 19:42:03\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:7:\"menu_id\";i:6;s:4:\"name\";s:10:\"Data Kelas\";s:10:\"route_name\";s:12:\"rombel.kelas\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:42:03\";s:10:\"updated_at\";s:19:\"2026-09-14 19:42:03\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:7;s:9:\"module_id\";i:3;s:4:\"name\";s:7:\"Wilayah\";s:10:\"route_name\";N;s:4:\"icon\";s:3:\"map\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:30\";s:10:\"updated_at\";s:19:\"2026-09-14 21:51:03\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:7;s:9:\"module_id\";i:3;s:4:\"name\";s:7:\"Wilayah\";s:10:\"route_name\";N;s:4:\"icon\";s:3:\"map\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:30\";s:10:\"updated_at\";s:19:\"2026-09-14 21:51:03\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:4:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:7:\"menu_id\";i:7;s:4:\"name\";s:8:\"Provinsi\";s:10:\"route_name\";s:16:\"wilayah.provinsi\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:57\";s:10:\"updated_at\";s:19:\"2026-09-14 21:41:57\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:7:\"menu_id\";i:7;s:4:\"name\";s:8:\"Provinsi\";s:10:\"route_name\";s:16:\"wilayah.provinsi\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:57\";s:10:\"updated_at\";s:19:\"2026-09-14 21:41:57\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kabupaten\";s:10:\"route_name\";s:17:\"wilayah.kabupaten\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:18\";s:10:\"updated_at\";s:19:\"2026-09-14 21:42:18\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kabupaten\";s:10:\"route_name\";s:17:\"wilayah.kabupaten\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:18\";s:10:\"updated_at\";s:19:\"2026-09-14 21:42:18\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kecamatan\";s:10:\"route_name\";s:17:\"wilayah.kecamatan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:40\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:13\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kecamatan\";s:10:\"route_name\";s:17:\"wilayah.kecamatan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:40\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:13\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:15;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kelurahan\";s:10:\"route_name\";s:17:\"wilayah.kelurahan\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:43:29\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:29\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:15;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kelurahan\";s:10:\"route_name\";s:17:\"wilayah.kelurahan\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:43:29\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:29\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:8;s:9:\"module_id\";i:3;s:4:\"name\";s:19:\"Konfigurasi Sekolah\";s:10:\"route_name\";N;s:4:\"icon\";s:7:\"sliders\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:11:37\";s:10:\"updated_at\";s:19:\"2026-09-14 22:11:37\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:8;s:9:\"module_id\";i:3;s:4:\"name\";s:19:\"Konfigurasi Sekolah\";s:10:\"route_name\";N;s:4:\"icon\";s:7:\"sliders\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:11:37\";s:10:\"updated_at\";s:19:\"2026-09-14 22:11:37\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:2:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:16;s:7:\"menu_id\";i:8;s:4:\"name\";s:12:\"Tahun Ajaran\";s:10:\"route_name\";s:32:\"konfigurasi-sekolah.tahun-ajaran\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:12:57\";s:10:\"updated_at\";s:19:\"2026-09-14 22:12:57\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:16;s:7:\"menu_id\";i:8;s:4:\"name\";s:12:\"Tahun Ajaran\";s:10:\"route_name\";s:32:\"konfigurasi-sekolah.tahun-ajaran\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:12:57\";s:10:\"updated_at\";s:19:\"2026-09-14 22:12:57\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:17;s:7:\"menu_id\";i:8;s:4:\"name\";s:17:\"Kalender Akademik\";s:10:\"route_name\";s:37:\"konfigurasi-sekolah.kalender-akademik\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:13:32\";s:10:\"updated_at\";s:19:\"2026-09-14 22:13:32\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:17;s:7:\"menu_id\";i:8;s:4:\"name\";s:17:\"Kalender Akademik\";s:10:\"route_name\";s:37:\"konfigurasi-sekolah.kalender-akademik\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:13:32\";s:10:\"updated_at\";s:19:\"2026-09-14 22:13:32\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:4;s:4:\"name\";s:8:\"AKADEMIK\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:30:03\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:4;s:4:\"name\";s:8:\"AKADEMIK\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:30:03\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:10;s:9:\"module_id\";i:4;s:4:\"name\";s:11:\"Absensi KBM\";s:10:\"route_name\";s:7:\"absensi\";s:4:\"icon\";s:14:\"clipboard-list\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:31:20\";s:10:\"updated_at\";s:19:\"2026-09-23 14:31:20\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:10;s:9:\"module_id\";i:4;s:4:\"name\";s:11:\"Absensi KBM\";s:10:\"route_name\";s:7:\"absensi\";s:4:\"icon\";s:14:\"clipboard-list\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:31:20\";s:10:\"updated_at\";s:19:\"2026-09-23 14:31:20\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:5;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:8;s:4:\"name\";s:16:\"FACE RECOGNITION\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-25 08:22:52\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:8;s:4:\"name\";s:16:\"FACE RECOGNITION\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-25 08:22:52\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:6;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:2;s:4:\"name\";s:17:\"PENGATURAN SISTEM\";s:5:\"order\";i:7;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:2;s:4:\"name\";s:17:\"PENGATURAN SISTEM\";s:5:\"order\";i:7;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:2:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:2;s:9:\"module_id\";i:2;s:4:\"name\";s:6:\"Sistem\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"settings\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:2;s:9:\"module_id\";i:2;s:4:\"name\";s:6:\"Sistem\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"settings\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:5:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:1;s:7:\"menu_id\";i:2;s:4:\"name\";s:5:\"Modul\";s:10:\"route_name\";s:20:\"system.modules.index\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:1;s:7:\"menu_id\";i:2;s:4:\"name\";s:5:\"Modul\";s:10:\"route_name\";s:20:\"system.modules.index\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:2;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"Menu\";s:10:\"route_name\";s:18:\"system.menus.index\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:2;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"Menu\";s:10:\"route_name\";s:18:\"system.menus.index\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:3;s:7:\"menu_id\";i:2;s:4:\"name\";s:8:\"Sub-Menu\";s:10:\"route_name\";s:22:\"system.sub-menus.index\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:3;s:7:\"menu_id\";i:2;s:4:\"name\";s:8:\"Sub-Menu\";s:10:\"route_name\";s:22:\"system.sub-menus.index\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:4;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"User\";s:10:\"route_name\";s:11:\"sistem.user\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 01:54:27\";s:10:\"updated_at\";s:19:\"2026-09-14 17:32:36\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:4;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"User\";s:10:\"route_name\";s:11:\"sistem.user\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 01:54:27\";s:10:\"updated_at\";s:19:\"2026-09-14 17:32:36\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:7:\"menu_id\";i:2;s:4:\"name\";s:9:\"Referensi\";s:10:\"route_name\";s:16:\"system.referensi\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-01 20:04:18\";s:10:\"updated_at\";s:19:\"2026-11-01 20:04:18\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:7:\"menu_id\";i:2;s:4:\"name\";s:9:\"Referensi\";s:10:\"route_name\";s:16:\"system.referensi\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-01 20:04:18\";s:10:\"updated_at\";s:19:\"2026-11-01 20:04:18\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:4;s:9:\"module_id\";i:2;s:4:\"name\";s:16:\"Backup & Restore\";s:10:\"route_name\";s:14:\"backup-restore\";s:4:\"icon\";s:6:\"folder\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 04:28:20\";s:10:\"updated_at\";s:19:\"2026-09-08 04:28:20\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:4;s:9:\"module_id\";i:2;s:4:\"name\";s:16:\"Backup & Restore\";s:10:\"route_name\";s:14:\"backup-restore\";s:4:\"icon\";s:6:\"folder\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 04:28:20\";s:10:\"updated_at\";s:19:\"2026-09-08 04:28:20\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}\";', '1795652696'),
('infora-cache-infora_role_templates_v1', 's:12308:\"O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:8:{i:0;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:13:\"admin_sekolah\";s:9:\"role_name\";s:13:\"Admin Sekolah\";s:13:\"role_category\";s:5:\"admin\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:13:\"admin_sekolah\";s:9:\"role_name\";s:13:\"Admin Sekolah\";s:13:\"role_category\";s:5:\"admin\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:13:\"guru_pengajar\";s:9:\"role_name\";s:13:\"Guru Pengajar\";s:13:\"role_category\";s:4:\"guru\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:13:\"guru_pengajar\";s:9:\"role_name\";s:13:\"Guru Pengajar\";s:13:\"role_category\";s:4:\"guru\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:17:\"wakasek_kesiswaan\";s:9:\"role_name\";s:32:\"Wakil Kepala Sekolah - Kesiswaan\";s:13:\"role_category\";s:4:\"guru\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:17:\"wakasek_kesiswaan\";s:9:\"role_name\";s:32:\"Wakil Kepala Sekolah - Kesiswaan\";s:13:\"role_category\";s:4:\"guru\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:17:\"wakasek_kurikulum\";s:9:\"role_name\";s:32:\"Wakil Kepala Sekolah - Kurikulum\";s:13:\"role_category\";s:4:\"guru\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:17:\"wakasek_kurikulum\";s:9:\"role_name\";s:32:\"Wakil Kepala Sekolah - Kurikulum\";s:13:\"role_category\";s:4:\"guru\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:10:\"wali_kelas\";s:9:\"role_name\";s:10:\"Wali Kelas\";s:13:\"role_category\";s:4:\"guru\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:10:\"wali_kelas\";s:9:\"role_name\";s:10:\"Wali Kelas\";s:13:\"role_category\";s:4:\"guru\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:5;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:9:\"murid_pkl\";s:9:\"role_name\";s:24:\"Murid PKL (SMK Kelas 12)\";s:13:\"role_category\";s:5:\"murid\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:9:\"murid_pkl\";s:9:\"role_name\";s:24:\"Murid PKL (SMK Kelas 12)\";s:13:\"role_category\";s:5:\"murid\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:6;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:13:\"murid_reguler\";s:9:\"role_name\";s:27:\"Murid Reguler (Kelas 10-11)\";s:13:\"role_category\";s:5:\"murid\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:13:\"murid_reguler\";s:9:\"role_name\";s:27:\"Murid Reguler (Kelas 10-11)\";s:13:\"role_category\";s:5:\"murid\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:7;O:29:\"App\\Models\\MenuAccessTemplate\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:21:\"menu_access_templates\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:3:{s:8:\"role_key\";s:7:\"staf_tu\";s:9:\"role_name\";s:15:\"Staf Tata Usaha\";s:13:\"role_category\";s:4:\"staf\";}s:11:\"\0*\0original\";a:3:{s:8:\"role_key\";s:7:\"staf_tu\";s:9:\"role_name\";s:15:\"Staf Tata Usaha\";s:13:\"role_category\";s:4:\"staf\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:4:{s:8:\"can_view\";s:7:\"boolean\";s:10:\"can_create\";s:7:\"boolean\";s:8:\"can_edit\";s:7:\"boolean\";s:10:\"can_delete\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:8:\"role_key\";i:1;s:9:\"role_name\";i:2;s:13:\"role_category\";i:3;s:7:\"menu_id\";i:4;s:11:\"sub_menu_id\";i:5;s:8:\"can_view\";i:6;s:10:\"can_create\";i:7;s:8:\"can_edit\";i:8;s:10:\"can_delete\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}\";', '1795652869'),
('infora-cache-infora_sidebar_nav_v1_user_1', 's:58396:\"O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:7:{i:0;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:1;s:4:\"name\";s:14:\"NAVIGASI UTAMA\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:13\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:1;s:4:\"name\";s:14:\"NAVIGASI UTAMA\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:13\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:2:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:1;s:9:\"module_id\";i:1;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:9:\"dashboard\";s:4:\"icon\";s:9:\"dashboard\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-23 11:42:23\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:1;s:9:\"module_id\";i:1;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:9:\"dashboard\";s:4:\"icon\";s:9:\"dashboard\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-23 11:42:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:5;s:9:\"module_id\";i:1;s:4:\"name\";s:12:\"Media Publik\";s:10:\"route_name\";s:2:\"tv\";s:4:\"icon\";s:5:\"globe\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:48:40\";s:10:\"updated_at\";s:19:\"2026-09-14 18:48:40\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:5;s:9:\"module_id\";i:1;s:4:\"name\";s:12:\"Media Publik\";s:10:\"route_name\";s:2:\"tv\";s:4:\"icon\";s:5:\"globe\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:48:40\";s:10:\"updated_at\";s:19:\"2026-09-14 18:48:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:5;s:4:\"name\";s:13:\"HALAMAN ADMIN\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:56:29\";s:10:\"updated_at\";s:19:\"2026-09-27 09:10:10\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:5;s:4:\"name\";s:13:\"HALAMAN ADMIN\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:56:29\";s:10:\"updated_at\";s:19:\"2026-09-27 09:10:10\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:11;s:9:\"module_id\";i:5;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:15:\"dashboard.admin\";s:4:\"icon\";s:6:\"school\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:58:28\";s:10:\"updated_at\";s:19:\"2026-09-27 08:59:31\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:11;s:9:\"module_id\";i:5;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:15:\"dashboard.admin\";s:4:\"icon\";s:6:\"school\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-27 08:58:28\";s:10:\"updated_at\";s:19:\"2026-09-27 08:59:31\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:6;s:4:\"name\";s:11:\"HALAMAN GTK\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:06:40\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:6;s:4:\"name\";s:11:\"HALAMAN GTK\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:06:40\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:12;s:9:\"module_id\";i:6;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:13:\"dashboard.gtk\";s:4:\"icon\";s:9:\"briefcase\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:07:16\";s:10:\"updated_at\";s:19:\"2026-10-19 20:23:26\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:12;s:9:\"module_id\";i:6;s:4:\"name\";s:9:\"Dashboard\";s:10:\"route_name\";s:13:\"dashboard.gtk\";s:4:\"icon\";s:9:\"briefcase\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-10-19 20:07:16\";s:10:\"updated_at\";s:19:\"2026-10-19 20:23:26\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"ADMINISTRASI\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:15:41\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"ADMINISTRASI\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:15:41\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:4:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:3;s:9:\"module_id\";i:3;s:4:\"name\";s:6:\"Master\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"database\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:16:32\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:54\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:3;s:9:\"module_id\";i:3;s:4:\"name\";s:6:\"Master\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"database\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:16:32\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:54\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:6:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:5;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Sekolah\";s:10:\"route_name\";s:19:\"master.data-sekolah\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:18:26\";s:10:\"updated_at\";s:19:\"2026-09-08 02:18:26\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:5;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Sekolah\";s:10:\"route_name\";s:19:\"master.data-sekolah\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 02:18:26\";s:10:\"updated_at\";s:19:\"2026-09-08 02:18:26\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:7:\"menu_id\";i:3;s:4:\"name\";s:14:\"Data Tingkatan\";s:10:\"route_name\";s:21:\"master.data-tingkatan\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:40:56\";s:10:\"updated_at\";s:19:\"2026-09-15 00:10:44\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:7:\"menu_id\";i:3;s:4:\"name\";s:14:\"Data Tingkatan\";s:10:\"route_name\";s:21:\"master.data-tingkatan\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:40:56\";s:10:\"updated_at\";s:19:\"2026-09-15 00:10:44\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Jurusan\";s:10:\"route_name\";s:19:\"master.data-jurusan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:41:33\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:08\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:7:\"menu_id\";i:3;s:4:\"name\";s:12:\"Data Jurusan\";s:10:\"route_name\";s:19:\"master.data-jurusan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:41:33\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:08\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:7:\"menu_id\";i:3;s:4:\"name\";s:19:\"Data Mata Pelajaran\";s:10:\"route_name\";s:17:\"master.data-mapel\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:39:08\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:25\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:7:\"menu_id\";i:3;s:4:\"name\";s:19:\"Data Mata Pelajaran\";s:10:\"route_name\";s:17:\"master.data-mapel\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:39:08\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:25\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:7:\"menu_id\";i:3;s:4:\"name\";s:28:\"Data Pendidik & Tendik (gtk)\";s:10:\"route_name\";s:15:\"master.data-gtk\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:05:21\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:37\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:7:\"menu_id\";i:3;s:4:\"name\";s:28:\"Data Pendidik & Tendik (gtk)\";s:10:\"route_name\";s:15:\"master.data-gtk\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:05:21\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:37\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:5;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:7:\"menu_id\";i:3;s:4:\"name\";s:10:\"Data Murid\";s:10:\"route_name\";s:17:\"master.data-murid\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:07:10\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:46\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:7:\"menu_id\";i:3;s:4:\"name\";s:10:\"Data Murid\";s:10:\"route_name\";s:17:\"master.data-murid\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:07:10\";s:10:\"updated_at\";s:19:\"2026-09-15 00:11:46\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:6;s:9:\"module_id\";i:3;s:4:\"name\";s:18:\"Rombel & Bimbingan\";s:10:\"route_name\";N;s:4:\"icon\";s:14:\"graduation-cap\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:52:26\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:26\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:6;s:9:\"module_id\";i:3;s:4:\"name\";s:18:\"Rombel & Bimbingan\";s:10:\"route_name\";N;s:4:\"icon\";s:14:\"graduation-cap\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 18:52:26\";s:10:\"updated_at\";s:19:\"2026-09-14 18:52:26\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:7:\"menu_id\";i:6;s:4:\"name\";s:10:\"Data Kelas\";s:10:\"route_name\";s:12:\"rombel.kelas\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:42:03\";s:10:\"updated_at\";s:19:\"2026-09-14 19:42:03\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:7:\"menu_id\";i:6;s:4:\"name\";s:10:\"Data Kelas\";s:10:\"route_name\";s:12:\"rombel.kelas\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 19:42:03\";s:10:\"updated_at\";s:19:\"2026-09-14 19:42:03\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:7;s:9:\"module_id\";i:3;s:4:\"name\";s:7:\"Wilayah\";s:10:\"route_name\";N;s:4:\"icon\";s:3:\"map\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:30\";s:10:\"updated_at\";s:19:\"2026-09-14 21:51:03\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:7;s:9:\"module_id\";i:3;s:4:\"name\";s:7:\"Wilayah\";s:10:\"route_name\";N;s:4:\"icon\";s:3:\"map\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:30\";s:10:\"updated_at\";s:19:\"2026-09-14 21:51:03\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:4:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:7:\"menu_id\";i:7;s:4:\"name\";s:8:\"Provinsi\";s:10:\"route_name\";s:16:\"wilayah.provinsi\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:57\";s:10:\"updated_at\";s:19:\"2026-09-14 21:41:57\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:7:\"menu_id\";i:7;s:4:\"name\";s:8:\"Provinsi\";s:10:\"route_name\";s:16:\"wilayah.provinsi\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:41:57\";s:10:\"updated_at\";s:19:\"2026-09-14 21:41:57\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kabupaten\";s:10:\"route_name\";s:17:\"wilayah.kabupaten\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:18\";s:10:\"updated_at\";s:19:\"2026-09-14 21:42:18\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kabupaten\";s:10:\"route_name\";s:17:\"wilayah.kabupaten\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:18\";s:10:\"updated_at\";s:19:\"2026-09-14 21:42:18\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kecamatan\";s:10:\"route_name\";s:17:\"wilayah.kecamatan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:40\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:13\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kecamatan\";s:10:\"route_name\";s:17:\"wilayah.kecamatan\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:42:40\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:13\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:15;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kelurahan\";s:10:\"route_name\";s:17:\"wilayah.kelurahan\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:43:29\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:29\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:15;s:7:\"menu_id\";i:7;s:4:\"name\";s:9:\"Kelurahan\";s:10:\"route_name\";s:17:\"wilayah.kelurahan\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 21:43:29\";s:10:\"updated_at\";s:19:\"2026-09-14 21:43:29\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:8;s:9:\"module_id\";i:3;s:4:\"name\";s:19:\"Konfigurasi Sekolah\";s:10:\"route_name\";N;s:4:\"icon\";s:7:\"sliders\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:11:37\";s:10:\"updated_at\";s:19:\"2026-09-14 22:11:37\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:8;s:9:\"module_id\";i:3;s:4:\"name\";s:19:\"Konfigurasi Sekolah\";s:10:\"route_name\";N;s:4:\"icon\";s:7:\"sliders\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:11:37\";s:10:\"updated_at\";s:19:\"2026-09-14 22:11:37\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:2:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:16;s:7:\"menu_id\";i:8;s:4:\"name\";s:12:\"Tahun Ajaran\";s:10:\"route_name\";s:32:\"konfigurasi-sekolah.tahun-ajaran\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:12:57\";s:10:\"updated_at\";s:19:\"2026-09-14 22:12:57\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:16;s:7:\"menu_id\";i:8;s:4:\"name\";s:12:\"Tahun Ajaran\";s:10:\"route_name\";s:32:\"konfigurasi-sekolah.tahun-ajaran\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:12:57\";s:10:\"updated_at\";s:19:\"2026-09-14 22:12:57\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:17;s:7:\"menu_id\";i:8;s:4:\"name\";s:17:\"Kalender Akademik\";s:10:\"route_name\";s:37:\"konfigurasi-sekolah.kalender-akademik\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:13:32\";s:10:\"updated_at\";s:19:\"2026-09-14 22:13:32\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:17;s:7:\"menu_id\";i:8;s:4:\"name\";s:17:\"Kalender Akademik\";s:10:\"route_name\";s:37:\"konfigurasi-sekolah.kalender-akademik\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-14 22:13:32\";s:10:\"updated_at\";s:19:\"2026-09-14 22:13:32\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:4;s:4:\"name\";s:8:\"AKADEMIK\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:30:03\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:4;s:4:\"name\";s:8:\"AKADEMIK\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:30:03\";s:10:\"updated_at\";s:19:\"2026-10-19 20:06:40\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:1:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:10;s:9:\"module_id\";i:4;s:4:\"name\";s:11:\"Absensi KBM\";s:10:\"route_name\";s:7:\"absensi\";s:4:\"icon\";s:14:\"clipboard-list\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:31:20\";s:10:\"updated_at\";s:19:\"2026-09-23 14:31:20\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:10;s:9:\"module_id\";i:4;s:4:\"name\";s:11:\"Absensi KBM\";s:10:\"route_name\";s:7:\"absensi\";s:4:\"icon\";s:14:\"clipboard-list\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-23 14:31:20\";s:10:\"updated_at\";s:19:\"2026-09-23 14:31:20\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:5;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:8;s:4:\"name\";s:16:\"FACE RECOGNITION\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-25 08:22:52\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:8;s:4:\"name\";s:16:\"FACE RECOGNITION\";s:5:\"order\";i:6;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-25 08:22:52\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:6;O:17:\"App\\Models\\Module\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:7:\"modules\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:6:{s:2:\"id\";i:2;s:4:\"name\";s:17:\"PENGATURAN SISTEM\";s:5:\"order\";i:7;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:11:\"\0*\0original\";a:6:{s:2:\"id\";i:2;s:4:\"name\";s:17:\"PENGATURAN SISTEM\";s:5:\"order\";i:7;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-11-25 08:22:52\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:5:\"menus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:2:{i:0;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:2;s:9:\"module_id\";i:2;s:4:\"name\";s:6:\"Sistem\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"settings\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:2;s:9:\"module_id\";i:2;s:4:\"name\";s:6:\"Sistem\";s:10:\"route_name\";N;s:4:\"icon\";s:8:\"settings\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:19\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:5:{i:0;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:1;s:7:\"menu_id\";i:2;s:4:\"name\";s:5:\"Modul\";s:10:\"route_name\";s:20:\"system.modules.index\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:1;s:7:\"menu_id\";i:2;s:4:\"name\";s:5:\"Modul\";s:10:\"route_name\";s:20:\"system.modules.index\";s:5:\"order\";i:1;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:2;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"Menu\";s:10:\"route_name\";s:18:\"system.menus.index\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:2;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"Menu\";s:10:\"route_name\";s:18:\"system.menus.index\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:2;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:3;s:7:\"menu_id\";i:2;s:4:\"name\";s:8:\"Sub-Menu\";s:10:\"route_name\";s:22:\"system.sub-menus.index\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:3;s:7:\"menu_id\";i:2;s:4:\"name\";s:8:\"Sub-Menu\";s:10:\"route_name\";s:22:\"system.sub-menus.index\";s:5:\"order\";i:3;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-07 07:26:20\";s:10:\"updated_at\";s:19:\"2026-09-14 20:05:14\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:3;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:4;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"User\";s:10:\"route_name\";s:11:\"sistem.user\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 01:54:27\";s:10:\"updated_at\";s:19:\"2026-09-14 17:32:36\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:4;s:7:\"menu_id\";i:2;s:4:\"name\";s:4:\"User\";s:10:\"route_name\";s:11:\"sistem.user\";s:5:\"order\";i:4;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 01:54:27\";s:10:\"updated_at\";s:19:\"2026-09-14 17:32:36\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:4;O:18:\"App\\Models\\SubMenu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:9:\"sub_menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:7:\"menu_id\";i:2;s:4:\"name\";s:9:\"Referensi\";s:10:\"route_name\";s:16:\"system.referensi\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-01 20:04:18\";s:10:\"updated_at\";s:19:\"2026-11-01 20:04:18\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:7:\"menu_id\";i:2;s:4:\"name\";s:9:\"Referensi\";s:10:\"route_name\";s:16:\"system.referensi\";s:5:\"order\";i:5;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-11-01 20:04:18\";s:10:\"updated_at\";s:19:\"2026-11-01 20:04:18\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:7:\"menu_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:5:\"order\";i:4;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}i:1;O:15:\"App\\Models\\Menu\":34:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:5:\"menus\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:12:\"\0*\0refreshes\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:9:{s:2:\"id\";i:4;s:9:\"module_id\";i:2;s:4:\"name\";s:16:\"Backup & Restore\";s:10:\"route_name\";s:14:\"backup-restore\";s:4:\"icon\";s:6:\"folder\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 04:28:20\";s:10:\"updated_at\";s:19:\"2026-09-08 04:28:20\";}s:11:\"\0*\0original\";a:9:{s:2:\"id\";i:4;s:9:\"module_id\";i:2;s:4:\"name\";s:16:\"Backup & Restore\";s:10:\"route_name\";s:14:\"backup-restore\";s:4:\"icon\";s:6:\"folder\";s:5:\"order\";i:2;s:9:\"is_active\";i:1;s:10:\"created_at\";s:19:\"2026-09-08 04:28:20\";s:10:\"updated_at\";s:19:\"2026-09-08 04:28:20\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:2:{s:5:\"order\";s:7:\"integer\";s:9:\"is_active\";s:7:\"boolean\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:1:{s:8:\"subMenus\";O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:6:{i:0;s:9:\"module_id\";i:1;s:4:\"name\";i:2;s:10:\"route_name\";i:3;s:4:\"icon\";i:4;s:5:\"order\";i:5;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:3:{i:0;s:4:\"name\";i:1;s:5:\"order\";i:2;s:9:\"is_active\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}\";', '1795652696'),
('infora-cache-referensi_options_accreditation', 'a:4:{s:1:\"A\";s:10:\"A (Unggul)\";s:1:\"B\";s:8:\"B (Baik)\";s:1:\"C\";s:9:\"C (Cukup)\";s:5:\"Belum\";s:19:\"Belum Terakreditasi\";}', '1795572170'),
('infora-cache-referensi_options_school_type', 'a:8:{s:3:\"SMA\";s:27:\"SMA (Sekolah Menengah Atas)\";s:3:\"SMK\";s:31:\"SMK (Sekolah Menengah Kejuruan)\";s:2:\"MA\";s:20:\"MA (Madrasah Aliyah)\";s:3:\"MAK\";s:30:\"MAK (Madrasah Aliyah Kejuruan)\";s:3:\"SMP\";s:30:\"SMP (Sekolah Menengah Pertama)\";s:3:\"MTs\";s:25:\"MTs (Madrasah Tsanawiyah)\";s:2:\"SD\";s:18:\"SD (Sekolah Dasar)\";s:2:\"MI\";s:24:\"MI (Madrasah Ibtidaiyah)\";}', '1795572170');

-- --------------------------------------------------------
-- Struktur Tabel untuk `cache_locks`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `cache_locks`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `failed_jobs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `failed_jobs`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `gtks`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `gtks`;
CREATE TABLE `gtks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gelar_depan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gelar_belakang` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_kelamin` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nip` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nuptk` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenis_ptk` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `status_kepegawaian` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_hp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provinsi_id` bigint unsigned DEFAULT NULL,
  `kabupaten_id` bigint unsigned DEFAULT NULL,
  `kecamatan_id` bigint unsigned DEFAULT NULL,
  `kelurahan_id` bigint unsigned DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `pendidikan_terakhir` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jurusan_pendidikan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gtks_school_id_foreign` (`school_id`),
  KEY `gtks_user_id_foreign` (`user_id`),
  KEY `gtks_provinsi_id_foreign` (`provinsi_id`),
  KEY `gtks_kabupaten_id_foreign` (`kabupaten_id`),
  KEY `gtks_kecamatan_id_foreign` (`kecamatan_id`),
  KEY `gtks_kelurahan_id_foreign` (`kelurahan_id`),
  KEY `gtks_nik_index` (`nik`),
  KEY `gtks_nip_index` (`nip`),
  KEY `gtks_nuptk_index` (`nuptk`),
  KEY `gtks_status_kepegawaian_index` (`status_kepegawaian`),
  KEY `gtks_is_active_index` (`is_active`),
  CONSTRAINT `gtks_kabupaten_id_foreign` FOREIGN KEY (`kabupaten_id`) REFERENCES `kabupaten` (`id`) ON DELETE SET NULL,
  CONSTRAINT `gtks_kecamatan_id_foreign` FOREIGN KEY (`kecamatan_id`) REFERENCES `kecamatan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `gtks_kelurahan_id_foreign` FOREIGN KEY (`kelurahan_id`) REFERENCES `kelurahan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `gtks_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsi` (`id`) ON DELETE SET NULL,
  CONSTRAINT `gtks_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `gtks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `gtks_chk_1` CHECK (json_valid(`jenis_ptk`))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `gtks`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `job_batches`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `job_batches`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `jobs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `jobs`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `jurusan`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE `jurusan` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `singkatan` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jenjang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SMK',
  `bidang_keahlian` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `program_keahlian` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kepala_jurusan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jurusan_school_id_is_active_index` (`school_id`,`is_active`),
  KEY `jurusan_school_id_kode_index` (`school_id`,`kode`),
  KEY `jurusan_kode_index` (`kode`),
  KEY `jurusan_jenjang_index` (`jenjang`),
  KEY `jurusan_is_active_index` (`is_active`),
  CONSTRAINT `jurusan_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `jurusan`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `kabupaten`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `kabupaten`;
CREATE TABLE `kabupaten` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provinsi_id` bigint unsigned NOT NULL,
  `kode` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Kabupaten',
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kabupaten_kode_unique` (`kode`),
  KEY `kabupaten_provinsi_id_foreign` (`provinsi_id`),
  KEY `kabupaten_tipe_index` (`tipe`),
  KEY `kabupaten_nama_index` (`nama`),
  KEY `kabupaten_status_index` (`status`),
  CONSTRAINT `kabupaten_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `kabupaten`
INSERT INTO `kabupaten` (`id`, `provinsi_id`, `kode`, `tipe`, `nama`, `status`, `created_at`, `updated_at`) VALUES
('1', '27', '7301', 'Kabupaten', 'Kepulauan Selayar', '1', '2026-09-15 01:53:19', '2026-09-15 01:53:19'),
('2', '27', '7302', 'Kabupaten', 'Bulukumba', '1', '2026-09-15 01:53:19', '2026-09-15 01:53:19'),
('3', '27', '7303', 'Kabupaten', 'Bantaeng', '1', '2026-09-15 01:53:19', '2026-09-15 01:53:19'),
('4', '27', '7304', 'Kabupaten', 'Jeneponto', '1', '2026-09-15 01:53:19', '2026-09-15 01:53:19'),
('5', '27', '7305', 'Kabupaten', 'Takalar', '1', '2026-09-15 01:53:19', '2026-09-15 01:53:19'),
('6', '27', '7306', 'Kabupaten', 'Gowa', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('7', '27', '7307', 'Kabupaten', 'Sinjai', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('8', '27', '7308', 'Kabupaten', 'Bone', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('9', '27', '7309', 'Kabupaten', 'Maros', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('10', '27', '7310', 'Kabupaten', 'Pangkajene Dan Kepulauan', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('11', '27', '7311', 'Kabupaten', 'Barru', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('12', '27', '7312', 'Kabupaten', 'Soppeng', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('13', '27', '7313', 'Kabupaten', 'Wajo', '1', '2026-09-15 01:53:20', '2026-09-15 01:53:20'),
('14', '27', '7314', 'Kabupaten', 'Sidenreng Rappang', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('15', '27', '7315', 'Kabupaten', 'Pinrang', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('16', '27', '7316', 'Kabupaten', 'Enrekang', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('17', '27', '7317', 'Kabupaten', 'Luwu', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('18', '27', '7318', 'Kabupaten', 'Tana Toraja', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('19', '27', '7322', 'Kabupaten', 'Luwu Utara', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('20', '27', '7324', 'Kabupaten', 'Luwu Timur', '1', '2026-09-15 01:53:21', '2026-09-15 01:53:21'),
('21', '27', '7326', 'Kabupaten', 'Toraja Utara', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('22', '27', '7371', 'Kota', 'Makassar', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('23', '27', '7372', 'Kota', 'Parepare', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('24', '27', '7373', 'Kota', 'Palopo', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('25', '11', '3101', 'Kabupaten', 'Kepulauan Seribu', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('26', '11', '3171', 'Kota', 'Jakarta Pusat', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('27', '11', '3172', 'Kota', 'Jakarta Utara', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('28', '11', '3173', 'Kota', 'Jakarta Barat', '1', '2026-09-15 01:53:22', '2026-09-15 01:53:22'),
('29', '11', '3174', 'Kota', 'Jakarta Selatan', '1', '2026-09-15 01:53:23', '2026-09-15 01:53:23'),
('30', '11', '3175', 'Kota', 'Jakarta Timur', '1', '2026-09-15 01:53:23', '2026-09-15 01:53:23');

-- --------------------------------------------------------
-- Struktur Tabel untuk `kalender_akademik`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `kalender_akademik`;
CREATE TABLE `kalender_akademik` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `judul_kegiatan` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `tahun_ajaran` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `warna` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blue',
  `libur_kbm` tinyint(1) NOT NULL DEFAULT '0',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kalender_akademik_school_id_tahun_ajaran_semester_index` (`school_id`,`tahun_ajaran`,`semester`),
  KEY `kalender_akademik_tanggal_mulai_index` (`tanggal_mulai`),
  KEY `kalender_akademik_tanggal_selesai_index` (`tanggal_selesai`),
  KEY `kalender_akademik_tahun_ajaran_index` (`tahun_ajaran`),
  KEY `kalender_akademik_semester_index` (`semester`),
  KEY `kalender_akademik_kategori_index` (`kategori`),
  KEY `kalender_akademik_libur_kbm_index` (`libur_kbm`),
  CONSTRAINT `kalender_akademik_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `kalender_akademik`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `kecamatan`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `kecamatan`;
CREATE TABLE `kecamatan` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kabupaten_id` bigint unsigned NOT NULL,
  `kode` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kecamatan_kode_unique` (`kode`),
  KEY `kecamatan_kabupaten_id_foreign` (`kabupaten_id`),
  KEY `kecamatan_nama_index` (`nama`),
  KEY `kecamatan_status_index` (`status`),
  CONSTRAINT `kecamatan_kabupaten_id_foreign` FOREIGN KEY (`kabupaten_id`) REFERENCES `kabupaten` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `kecamatan`
INSERT INTO `kecamatan` (`id`, `kabupaten_id`, `kode`, `nama`, `status`, `created_at`, `updated_at`) VALUES
('1', '8', '730801', 'Bontocani', '1', '2026-09-15 02:30:01', '2026-09-15 02:30:01'),
('2', '8', '730802', 'Kahu', '1', '2026-09-15 02:30:01', '2026-09-15 02:30:01'),
('3', '8', '730803', 'Kajuara', '1', '2026-09-15 02:30:01', '2026-09-15 02:30:01'),
('4', '8', '730804', 'Salomekko', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('5', '8', '730805', 'Tonra', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('6', '8', '730806', 'Libureng', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('7', '8', '730807', 'Mare', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('8', '8', '730808', 'Sibulue', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('9', '8', '730809', 'Barebbo', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('10', '8', '730810', 'Cina', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('11', '8', '730811', 'Ponre', '1', '2026-09-15 02:30:02', '2026-09-15 02:30:02'),
('12', '8', '730812', 'Lappariaja', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('13', '8', '730813', 'Lamuru', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('14', '8', '730814', 'Ulaweng', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('15', '8', '730815', 'Palakka', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('16', '8', '730816', 'Awangpone', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('17', '8', '730817', 'Tellu Siattinge', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('18', '8', '730818', 'Ajangale', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('19', '8', '730819', 'Dua Boccoe', '1', '2026-09-15 02:30:03', '2026-09-15 02:30:03'),
('20', '8', '730820', 'Cenrana', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('21', '8', '730821', 'Tanete Riattang', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('22', '8', '730822', 'Tanete Riattang Barat', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('23', '8', '730823', 'Tanete Riattang Timur', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('24', '8', '730824', 'Amali', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('25', '8', '730825', 'Tellu Limpoe', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('26', '8', '730826', 'Bengo', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04'),
('27', '8', '730827', 'Patimpeng', '1', '2026-09-15 02:30:04', '2026-09-15 02:30:04');

-- --------------------------------------------------------
-- Struktur Tabel untuk `kelas`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `kelas`;
CREATE TABLE `kelas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `tahun_ajaran_id` bigint unsigned NOT NULL,
  `tingkatan_id` bigint unsigned NOT NULL,
  `jurusan_id` bigint unsigned DEFAULT NULL,
  `wali_kelas_id` bigint unsigned DEFAULT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ruangan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kapasitas` smallint unsigned NOT NULL DEFAULT '36',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kelas_school_ta_nama_unique` (`school_id`,`tahun_ajaran_id`,`nama`),
  KEY `kelas_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  KEY `kelas_jurusan_id_foreign` (`jurusan_id`),
  KEY `kelas_wali_kelas_id_foreign` (`wali_kelas_id`),
  KEY `kelas_school_id_tahun_ajaran_id_is_active_index` (`school_id`,`tahun_ajaran_id`,`is_active`),
  KEY `kelas_tingkatan_id_jurusan_id_index` (`tingkatan_id`,`jurusan_id`),
  KEY `kelas_school_id_wali_kelas_id_index` (`school_id`,`wali_kelas_id`),
  KEY `kelas_is_active_index` (`is_active`),
  CONSTRAINT `kelas_jurusan_id_foreign` FOREIGN KEY (`jurusan_id`) REFERENCES `jurusan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `kelas_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kelas_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajaran` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kelas_tingkatan_id_foreign` FOREIGN KEY (`tingkatan_id`) REFERENCES `tingkatan` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kelas_wali_kelas_id_foreign` FOREIGN KEY (`wali_kelas_id`) REFERENCES `gtks` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `kelas`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `kelurahan`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `kelurahan`;
CREATE TABLE `kelurahan` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kecamatan_id` bigint unsigned NOT NULL,
  `kode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Kelurahan',
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode_pos` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kelurahan_kode_unique` (`kode`),
  KEY `kelurahan_kecamatan_id_foreign` (`kecamatan_id`),
  KEY `kelurahan_tipe_index` (`tipe`),
  KEY `kelurahan_nama_index` (`nama`),
  KEY `kelurahan_kode_pos_index` (`kode_pos`),
  KEY `kelurahan_status_index` (`status`),
  CONSTRAINT `kelurahan_kecamatan_id_foreign` FOREIGN KEY (`kecamatan_id`) REFERENCES `kecamatan` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `kelurahan`
INSERT INTO `kelurahan` (`id`, `kecamatan_id`, `kode`, `tipe`, `nama`, `kode_pos`, `status`, `created_at`, `updated_at`) VALUES
('1', '1', '7308011001', 'Kelurahan', 'Kahu', '92777', '1', '2026-09-15 02:45:52', '2026-09-15 02:45:52'),
('2', '1', '7308012002', 'Desa', 'Bana', '92777', '1', '2026-09-15 02:45:52', '2026-09-15 02:45:52'),
('3', '1', '7308012003', 'Desa', 'Bontojai', '92777', '1', '2026-09-15 02:45:52', '2026-09-15 02:45:52'),
('4', '1', '7308012004', 'Desa', 'Bulu Sirua', '92777', '1', '2026-09-15 02:45:52', '2026-09-15 02:45:52'),
('5', '1', '7308012005', 'Desa', 'Langi', '92777', '1', '2026-09-15 02:45:52', '2026-09-15 02:45:52'),
('6', '1', '7308012006', 'Desa', 'Mattirowalie', '92777', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('7', '1', '7308012007', 'Desa', 'Pammusureng', '92777', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('8', '1', '7308012008', 'Desa', 'Pattuku', '92777', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('9', '1', '7308012009', 'Desa', 'Watang Cani', '92777', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('10', '2', '7308021001', 'Kelurahan', 'Palattae', '92773', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('11', '2', '7308022002', 'Desa', 'Arallae', '92773', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('12', '2', '7308022003', 'Desa', 'Biru', '92773', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('13', '2', '7308022004', 'Desa', 'Bonto Padang', '92773', '1', '2026-09-15 02:45:53', '2026-09-15 02:45:53'),
('14', '2', '7308022005', 'Desa', 'Cakkela', '92773', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('15', '2', '7308022006', 'Desa', 'Cammilo', '92773', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('16', '2', '7308022007', 'Desa', 'Carima', '92773', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('17', '2', '7308022008', 'Desa', 'Cenrana', '92773', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('18', '3', '7308031001', 'Kelurahan', 'Awang Tangka', '92776', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('19', '3', '7308032002', 'Desa', 'Ancu', '92776', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('20', '3', '7308032003', 'Desa', 'Angkue', '92776', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('21', '3', '7308032004', 'Desa', 'Buareng', '92776', '1', '2026-09-15 02:45:54', '2026-09-15 02:45:54'),
('22', '3', '7308032005', 'Desa', 'Bulu Tanah', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('23', '3', '7308032006', 'Desa', 'Gona', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('24', '3', '7308032007', 'Desa', 'Kalero', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('25', '3', '7308032008', 'Desa', 'Lappa Bosse', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('26', '3', '7308032009', 'Desa', 'Mallahae', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('27', '3', '7308032010', 'Desa', 'Polewali', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('28', '3', '7308032011', 'Desa', 'Pude', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('29', '3', '7308032012', 'Desa', 'Raja', '92776', '1', '2026-09-15 02:45:55', '2026-09-15 02:45:55'),
('30', '3', '7308032013', 'Desa', 'Tarasu', '92776', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('31', '3', '7308032014', 'Desa', 'Waetuwo', '92776', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('32', '4', '7308041001', 'Kelurahan', 'Pancaitana', '92775', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('33', '4', '7308042002', 'Desa', 'Bellu', '92775', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('34', '4', '7308042003', 'Desa', 'Gattareng', '92775', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('35', '4', '7308042004', 'Desa', 'Malimongeng', '92775', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('36', '4', '7308042005', 'Desa', 'Manera', '92775', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('37', '4', '7308042006', 'Desa', 'Mappatoba', '92775', '1', '2026-09-15 02:45:56', '2026-09-15 02:45:56'),
('38', '4', '7308042007', 'Desa', 'Tebba', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('39', '5', '7308052001', 'Desa', 'Bacu', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('40', '5', '7308052002', 'Desa', 'Biccoing', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('41', '5', '7308052003', 'Desa', 'Bonepute', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('42', '5', '7308052004', 'Desa', 'Bulu-Bulu', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('43', '5', '7308052005', 'Desa', 'Gareccing', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('44', '5', '7308052006', 'Desa', 'Libureng', '92775', '1', '2026-09-15 02:45:57', '2026-09-15 02:45:57'),
('45', '5', '7308052007', 'Desa', 'Muara', '92775', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('46', '5', '7308052008', 'Desa', 'Padang Loang', '92775', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('47', '5', '7308052009', 'Desa', 'Rappo', '92775', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('48', '5', '7308052010', 'Desa', 'Samaenre', '92775', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('49', '5', '7308052011', 'Desa', 'Ujunge', '92775', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('50', '6', '7308061001', 'Kelurahan', 'Ceppaga', '92766', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('51', '6', '7308061002', 'Kelurahan', 'Tanah Batue', '92766', '1', '2026-09-15 02:45:58', '2026-09-15 02:45:58'),
('52', '6', '7308062003', 'Desa', 'Baringeng', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('53', '6', '7308062004', 'Desa', 'Binuang', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('54', '6', '7308062005', 'Desa', 'Cege', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('55', '6', '7308062006', 'Desa', 'Laburasseng', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('56', '6', '7308062007', 'Desa', 'Mallinrung', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('57', '6', '7308062008', 'Desa', 'Mario', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('58', '6', '7308062009', 'Desa', 'Mattiro Bulu', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('59', '6', '7308062010', 'Desa', 'Mattiro Walie', '92766', '1', '2026-09-15 02:45:59', '2026-09-15 02:45:59'),
('60', '6', '7308062011', 'Desa', 'Poleonro', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('61', '6', '7308062012', 'Desa', 'Polewali', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('62', '6', '7308062013', 'Desa', 'Ponre-Ponre', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('63', '6', '7308062014', 'Desa', 'Suwa', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('64', '6', '7308062015', 'Desa', 'Swadaya', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('65', '6', '7308062016', 'Desa', 'Tappale', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('66', '6', '7308062017', 'Desa', 'Tompong Patu', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('67', '6', '7308062018', 'Desa', 'Wanuawaru', '92766', '1', '2026-09-15 02:46:00', '2026-09-15 02:46:00'),
('68', '6', '7308062019', 'Desa', 'Pitumpidange', '92766', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('69', '7', '7308071001', 'Kelurahan', 'Padaelo', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('70', '7', '7308072002', 'Desa', 'Batu Gading', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('71', '7', '7308072003', 'Desa', 'Cege', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('72', '7', '7308072004', 'Desa', 'Data', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('73', '7', '7308072005', 'Desa', 'Kadai', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('74', '7', '7308072006', 'Desa', 'Karella', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('75', '7', '7308072007', 'Desa', 'Lakukang', '92773', '1', '2026-09-15 02:46:01', '2026-09-15 02:46:01'),
('76', '7', '7308072008', 'Desa', 'Lapasa', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('77', '7', '7308072009', 'Desa', 'Mario', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('78', '7', '7308072010', 'Desa', 'Mattampa Walie', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('79', '7', '7308072011', 'Desa', 'Mattiro Walie', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('80', '7', '7308072012', 'Desa', 'Sumaling', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('81', '7', '7308072013', 'Desa', 'Tellu Boccoe', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('82', '7', '7308072014', 'Desa', 'Ujung Salangketo', '92773', '1', '2026-09-15 02:46:02', '2026-09-15 02:46:02'),
('83', '7', '7308072015', 'Desa', 'Ujung Tanah', '92773', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('84', '7', '7308072016', 'Desa', 'Tellongeng', '92773', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('85', '7', '7308072017', 'Desa', 'Pattiro', '92773', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('86', '8', '7308081008', 'Kelurahan', 'Maroanging', '92781', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('87', '8', '7308082001', 'Desa', 'Acekke', '92781', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('88', '8', '7308082002', 'Desa', 'Balieng Toa', '92781', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('89', '8', '7308082003', 'Desa', 'Cinnong', '92781', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('90', '8', '7308082004', 'Desa', 'Kalibong', '92781', '1', '2026-09-15 02:46:03', '2026-09-15 02:46:03'),
('91', '8', '7308082005', 'Desa', 'Letta Tanah', '92781', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('92', '8', '7308082006', 'Desa', 'Mabbiring', '92781', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('93', '8', '7308082007', 'Desa', 'Mallusetasi', '92781', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('94', '9', '7308091008', 'Kelurahan', 'Apala', '92771', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('95', '9', '7308092001', 'Desa', 'Bacu', '92771', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('96', '9', '7308092002', 'Desa', 'Barebbo', '92771', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('97', '9', '7308092003', 'Desa', 'Cempaniga', '92771', '1', '2026-09-15 02:46:04', '2026-09-15 02:46:04'),
('98', '9', '7308092004', 'Desa', 'Cingkang', '92771', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('99', '9', '7308092005', 'Desa', 'Kading', '92771', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('100', '9', '7308092006', 'Desa', 'Parippung', '92771', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('101', '9', '7308092007', 'Desa', 'Samaelo', '92771', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('102', '10', '7308101001', 'Kelurahan', 'Tanete', '92772', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('103', '10', '7308102002', 'Desa', 'Abbumpungeng', '92772', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('104', '10', '7308102003', 'Desa', 'Ajangale', '92772', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('105', '10', '7308102004', 'Desa', 'Arasoe', '92772', '1', '2026-09-15 02:46:05', '2026-09-15 02:46:05'),
('106', '10', '7308102005', 'Desa', 'Awo', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('107', '10', '7308102006', 'Desa', 'Cinennung', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('108', '10', '7308102007', 'Desa', 'Kanco', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('109', '10', '7308102008', 'Desa', 'Kawerang', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('110', '10', '7308102009', 'Desa', 'Lompu', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('111', '10', '7308102010', 'Desa', 'Padang Loang', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('112', '10', '7308102011', 'Desa', 'Walimpong', '92772', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('113', '11', '7308112001', 'Desa', 'Bolli', '92765', '1', '2026-09-15 02:46:06', '2026-09-15 02:46:06'),
('114', '11', '7308112002', 'Desa', 'Mappesangka', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('115', '11', '7308112003', 'Desa', 'Mattampae', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('116', '11', '7308112004', 'Desa', 'Pattimpa', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('117', '11', '7308112005', 'Desa', 'Poleonro', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('118', '11', '7308112006', 'Desa', 'Salebba', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('119', '11', '7308112007', 'Desa', 'Tellu Boccoe', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('120', '11', '7308112008', 'Desa', 'Tompo Bulu', '92765', '1', '2026-09-15 02:46:07', '2026-09-15 02:46:07'),
('121', '11', '7308112009', 'Desa', 'Turu Adae', '92765', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('122', '12', '7308122001', 'Desa', 'Lili Riattang', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('123', '12', '7308122002', 'Desa', 'Mattiro Walie', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('124', '12', '7308122003', 'Desa', 'Pattuku Limpoe', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('125', '12', '7308122004', 'Desa', 'Sengeng Palie', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('126', '12', '7308122005', 'Desa', 'Tenri Pakkua', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('127', '12', '7308122006', 'Desa', 'Tonronge', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('128', '12', '7308122007', 'Desa', 'Ujung Lamuru', '92763', '1', '2026-09-15 02:46:08', '2026-09-15 02:46:08'),
('129', '12', '7308122008', 'Desa', 'Waekeccee', '92763', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('130', '12', '7308122009', 'Desa', 'Patangkai', '92763', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('131', '13', '7308131001', 'Kelurahan', 'Lalebata', '92762', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('132', '13', '7308132002', 'Desa', 'Barakkae', '92762', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('133', '13', '7308132003', 'Desa', 'Barugae', '92762', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('134', '13', '7308132004', 'Desa', 'Mamminasae', '92762', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('135', '13', '7308132005', 'Desa', 'Mattampa Bulu', '92762', '1', '2026-09-15 02:46:09', '2026-09-15 02:46:09'),
('136', '13', '7308132006', 'Desa', 'Mattampa Walie', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('137', '13', '7308132007', 'Desa', 'Padaelo', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('138', '13', '7308132008', 'Desa', 'Poleonro', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('139', '13', '7308132009', 'Desa', 'Seberang', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('140', '13', '7308132010', 'Desa', 'Sengeng Palie', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('141', '13', '7308132011', 'Desa', 'Turucinnae', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('142', '14', '7308141001', 'Kelurahan', 'Cinnong', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('143', '14', '7308142002', 'Desa', 'Ausu', '92762', '1', '2026-09-15 02:46:10', '2026-09-15 02:46:10'),
('144', '14', '7308142003', 'Desa', 'Cani Sirenreng', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('145', '14', '7308142004', 'Desa', 'Galung', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('146', '14', '7308142005', 'Desa', 'Jalamancae', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('147', '14', '7308142006', 'Desa', 'Lamakkaraseng', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('148', '14', '7308142007', 'Desa', 'Lilina Ajangale', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('149', '14', '7308142008', 'Desa', 'Manurunge', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('150', '14', '7308142009', 'Desa', 'Mula Menree', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('151', '14', '7308142010', 'Desa', 'Pallawa Rukka', '92762', '1', '2026-09-15 02:46:11', '2026-09-15 02:46:11'),
('152', '14', '7308142011', 'Desa', 'Timusu', '92762', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('153', '14', '7308142012', 'Desa', 'Tea Musu', '92762', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('154', '14', '7308142013', 'Desa', 'Tea Malala', '92762', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('155', '14', '7308142014', 'Desa', 'Tadang Palie', '92762', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('156', '15', '7308152001', 'Desa', 'Bainang', '92761', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('157', '15', '7308152002', 'Desa', 'Cinennung', '92761', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('158', '15', '7308152003', 'Desa', 'Melle', '92761', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('159', '15', '7308152004', 'Desa', 'Maduri', '92761', '1', '2026-09-15 02:46:12', '2026-09-15 02:46:12'),
('160', '15', '7308152005', 'Desa', 'Passippo', '92761', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('161', '15', '7308152006', 'Desa', 'Siame', '92761', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('162', '15', '7308152007', 'Desa', 'Tanah Tenga', '92761', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('163', '15', '7308152008', 'Desa', 'Ureng', '92761', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('164', '15', '7308152009', 'Desa', 'Usmanu', '92761', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('165', '16', '7308162001', 'Desa', 'Abbanuange', '92751', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('166', '16', '7308162002', 'Desa', 'Awolagading', '92751', '1', '2026-09-15 02:46:13', '2026-09-15 02:46:13'),
('167', '16', '7308162003', 'Desa', 'Kading', '92751', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('168', '16', '7308162004', 'Desa', 'Lappo Ase', '92751', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('169', '16', '7308162005', 'Desa', 'Maccope', '92751', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('170', '16', '7308162006', 'Desa', 'Matuju', '92751', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('171', '16', '7308162007', 'Desa', 'Paccing', '92751', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('172', '17', '7308171001', 'Kelurahan', 'Tokaseng', '92752', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('173', '17', '7308172002', 'Desa', 'Ajjalireng', '92752', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('174', '17', '7308172003', 'Desa', 'Itterung', '92752', '1', '2026-09-15 02:46:14', '2026-09-15 02:46:14'),
('175', '17', '7308172004', 'Desa', 'Lamuru', '92752', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('176', '17', '7308172005', 'Desa', 'Lanca', '92752', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('177', '17', '7308172006', 'Desa', 'Mattoanging', '92752', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('178', '17', '7308172007', 'Desa', 'Padaelo', '92752', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('179', '17', '7308172008', 'Desa', 'Palongki', '92752', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('180', '17', '7308172009', 'Desa', 'Patangnga', '92752', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('181', '18', '7308181001', 'Kelurahan', 'Pompanua', '92755', '1', '2026-09-15 02:46:15', '2026-09-15 02:46:15'),
('182', '18', '7308181002', 'Kelurahan', 'Pompanua Riattang', '92755', '1', '2026-09-15 02:46:16', '2026-09-15 02:46:16'),
('183', '18', '7308182009', 'Desa', 'Allamungeng Patue', '92755', '1', '2026-09-15 02:46:16', '2026-09-15 02:46:16'),
('184', '18', '7308182004', 'Desa', 'Pinceng Pute', '92755', '1', '2026-09-15 02:46:16', '2026-09-14 22:38:41'),
('185', '18', '7308182005', 'Desa', 'Opo', '92755', '1', '2026-09-15 02:46:16', '2026-09-14 22:38:41'),
('186', '18', '7308182006', 'Desa', 'Labissa', '92755', '1', '2026-09-15 02:46:16', '2026-09-14 22:38:41'),
('187', '18', '7308182007', 'Desa', 'Timurung', '92755', '1', '2026-09-15 02:46:16', '2026-09-14 22:38:41'),
('188', '18', '7308182008', 'Desa', 'Leppangeng', '92755', '1', '2026-09-15 02:46:16', '2026-09-14 22:38:41'),
('189', '18', '7308182014', 'Desa', 'Pacciro', '92755', '1', '2026-09-15 02:46:16', '2026-09-15 02:46:16'),
('190', '18', '7308182010', 'Desa', 'Amessangeng', '92755', '1', '2026-09-15 02:46:17', '2026-09-14 22:38:41'),
('191', '18', '7308182011', 'Desa', 'Lebbae', '92755', '1', '2026-09-15 02:46:17', '2026-09-14 22:38:42'),
('192', '19', '7308191001', 'Kelurahan', 'Unyi', '92753', '1', '2026-09-15 02:46:17', '2026-11-25 02:47:46'),
('193', '19', '7308192002', 'Desa', 'Mario', '92753', '1', '2026-09-15 02:46:17', '2026-11-25 02:48:06'),
('194', '19', '7308192003', 'Desa', 'Laccori', '92753', '1', '2026-09-15 02:46:17', '2026-11-25 02:48:21'),
('195', '19', '7308192004', 'Desa', 'Pattiro', '92753', '1', '2026-09-15 02:46:17', '2026-11-25 02:48:34'),
('196', '19', '7308192005', 'Desa', 'Cabbeng', '92753', '1', '2026-09-15 02:46:17', '2026-11-25 02:48:49'),
('197', '19', '7308192006', 'Desa', 'Panyili', '92753', '1', '2026-09-15 02:46:17', '2026-11-25 02:51:06'),
('198', '19', '7308192007', 'Desa', 'Sanrangeng', '92753', '1', '2026-09-15 02:46:18', '2026-09-15 02:46:18'),
('199', '19', '7308192008', 'Desa', 'Sailong', '92753', '1', '2026-09-15 02:46:18', '2026-11-25 02:51:40'),
('200', '19', '7308192009', 'Desa', 'Melle', '92753', '1', '2026-09-15 02:46:18', '2026-11-25 02:51:55'),
('201', '19', '7308192010', 'Desa', 'Pakkasalo', '92753', '1', '2026-09-15 02:46:18', '2026-11-25 02:52:09'),
('202', '20', '7308201001', 'Kelurahan', 'Cenrana', '92754', '1', '2026-09-15 02:46:18', '2026-09-15 02:46:18'),
('203', '20', '7308202002', 'Desa', 'Awolagading', '92754', '1', '2026-09-15 02:46:18', '2026-09-15 02:46:18'),
('204', '20', '7308202003', 'Desa', 'Cakkaware', '92754', '1', '2026-09-15 02:46:18', '2026-09-15 02:46:18'),
('205', '20', '7308202004', 'Desa', 'Labotto', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('206', '20', '7308202005', 'Desa', 'Laoni', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('207', '20', '7308202006', 'Desa', 'Latonro', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('208', '20', '7308202007', 'Desa', 'Nagauleng', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('209', '20', '7308202008', 'Desa', 'Pacubbe', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('210', '20', '7308202009', 'Desa', 'Pallae', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('211', '20', '7308202010', 'Desa', 'Pallime', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('212', '20', '7308202011', 'Desa', 'Panyiwi', '92754', '1', '2026-09-15 02:46:19', '2026-09-15 02:46:19'),
('213', '20', '7308202012', 'Desa', 'Pusung', '92754', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('214', '20', '7308202013', 'Desa', 'Watang Ta', '92754', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('215', '20', '7308202014', 'Desa', 'Watu', '92754', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('216', '20', '7308202015', 'Desa', 'Ujung Tanah', '92754', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('217', '21', '7308211001', 'Kelurahan', 'Biru', '92711', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('218', '21', '7308211002', 'Kelurahan', 'Bukaka', '92716', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('219', '21', '7308211003', 'Kelurahan', 'Masumpu', '92718', '1', '2026-09-15 02:46:20', '2026-09-15 02:46:20'),
('220', '21', '7308211004', 'Kelurahan', 'Manurunge', '92712', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('221', '21', '7308211005', 'Kelurahan', 'Pappolo', '92717', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('222', '21', '7308211006', 'Kelurahan', 'Ta', '92713', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('223', '21', '7308211007', 'Kelurahan', 'Walannae', '92715', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('224', '21', '7308211008', 'Kelurahan', 'Watampone', '92711', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('225', '22', '7308221001', 'Kelurahan', 'Bulu Tempe', '92731', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('226', '22', '7308221002', 'Kelurahan', 'Jeppe\'e', '92733', '1', '2026-09-15 02:46:21', '2026-09-15 02:46:21'),
('227', '22', '7308221003', 'Kelurahan', 'Macanang', '92732', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('228', '22', '7308221004', 'Kelurahan', 'Majang', '92734', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('229', '22', '7308221005', 'Kelurahan', 'Mattiro Walie', '92735', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('230', '22', '7308221006', 'Kelurahan', 'Polewali', '92735', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('231', '22', '7308221007', 'Kelurahan', 'Tibojong', '92736', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('232', '22', '7308221008', 'Kelurahan', 'Watang Palakka', '92734', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('233', '23', '7308231001', 'Kelurahan', 'Bajoe', '92721', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('234', '23', '7308231002', 'Kelurahan', 'Cellu', '92723', '1', '2026-09-15 02:46:22', '2026-09-15 02:46:22'),
('235', '23', '7308231003', 'Kelurahan', 'Lonrae', '92725', '1', '2026-09-15 02:46:23', '2026-09-15 02:46:23'),
('236', '23', '7308231004', 'Kelurahan', 'Panyula', '92722', '1', '2026-09-15 02:46:23', '2026-09-15 02:46:23'),
('237', '23', '7308231005', 'Kelurahan', 'Pallette', '92726', '1', '2026-09-15 02:46:23', '2026-09-15 02:46:23'),
('238', '23', '7308231006', 'Kelurahan', 'Toro', '92724', '1', '2026-09-15 02:46:23', '2026-09-15 02:46:23'),
('239', '23', '7308231007', 'Kelurahan', 'Waetuo', '92727', '1', '2026-09-15 02:46:23', '2026-09-15 02:46:23'),
('240', '23', '7308231008', 'Kelurahan', 'Rompe', '92728', '1', '2026-09-15 02:46:23', '2026-09-15 02:46:23'),
('241', '24', '7308241001', 'Kelurahan', 'Liliriattang', '92764', '1', '2026-09-15 02:46:23', '2026-11-24 16:17:12'),
('242', '24', '7308242012', 'Desa', 'Ajanglaleng', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:06:46'),
('243', '24', '7308242003', 'Desa', 'Ulaweng Riaja', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:19:23'),
('244', '24', '7308242009', 'Desa', 'Benteng Tellue', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:14:24'),
('245', '24', '7308242013', 'Desa', 'Bila', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:13:45'),
('246', '24', '7308242006', 'Desa', 'Amali Riattang', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:22:51'),
('247', '24', '7308242002', 'Desa', 'Mattaro Purae', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:09:57'),
('248', '24', '7308242014', 'Desa', 'Tacipong', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:05:24'),
('249', '24', '7308242007', 'Desa', 'Taccipi', '92764', '1', '2026-09-15 02:46:24', '2026-11-24 16:12:04'),
('250', '24', '7308242010', 'Desa', 'Ta\'dung Lawo', '92764', '1', '2026-09-15 02:46:25', '2026-09-15 02:46:25'),
('251', '24', '7308242011', 'Desa', 'Laponrong', '92764', '1', '2026-09-15 02:46:25', '2026-11-24 16:23:50'),
('252', '24', '7308242008', 'Desa', 'Wellulang', '92764', '1', '2026-09-15 02:46:25', '2026-11-24 16:06:28'),
('253', '25', '7308252001', 'Desa', 'Batu Putih', '92767', '1', '2026-09-15 02:46:25', '2026-09-15 02:46:25'),
('254', '25', '7308252002', 'Desa', 'Bonto Masunggu', '92767', '1', '2026-09-15 02:46:25', '2026-09-15 02:46:25'),
('255', '25', '7308252003', 'Desa', 'Gaya Baru', '92767', '1', '2026-09-15 02:46:25', '2026-09-15 02:46:25'),
('256', '25', '7308252004', 'Desa', 'Lagori', '92767', '1', '2026-09-15 02:46:25', '2026-09-15 02:46:25'),
('257', '25', '7308252005', 'Desa', 'Pallawa', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('258', '25', '7308252006', 'Desa', 'Polewali', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('259', '25', '7308252007', 'Desa', 'Sadar', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('260', '25', '7308252008', 'Desa', 'Samaturue', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('261', '25', '7308252009', 'Desa', 'Tapong', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('262', '25', '7308252010', 'Desa', 'Tellang Kere', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('263', '25', '7308252011', 'Desa', 'Tondong', '92767', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('264', '26', '7308262001', 'Desa', 'Bengo', '92763', '1', '2026-09-15 02:46:26', '2026-09-15 02:46:26'),
('265', '26', '7308262002', 'Desa', 'Bulu Allaporenge', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('266', '26', '7308262003', 'Desa', 'Lili Riawang', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('267', '26', '7308262004', 'Desa', 'Mattaropocci', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('268', '26', '7308262005', 'Desa', 'Selli', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('269', '26', '7308262006', 'Desa', 'Samaenre', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('270', '26', '7308262007', 'Desa', 'Tungke', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('271', '26', '7308262008', 'Desa', 'Walimpong', '92763', '1', '2026-09-15 02:46:27', '2026-09-15 02:46:27'),
('272', '27', '7308272001', 'Desa', 'Batulappa', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('273', '27', '7308272002', 'Desa', 'Bulu Ulaweng', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('274', '27', '7308272003', 'Desa', 'Masago', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('275', '27', '7308272004', 'Desa', 'Patimpeng', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('276', '27', '7308272005', 'Desa', 'Pationgi', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('277', '27', '7308272006', 'Desa', 'Poleonro', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('278', '27', '7308272007', 'Desa', 'Suka Maju', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('279', '27', '7308272008', 'Desa', 'Talabangi', '92774', '1', '2026-09-15 02:46:28', '2026-09-15 02:46:28'),
('280', '27', '7308272009', 'Desa', 'Tompobulu', '92774', '1', '2026-09-15 02:46:29', '2026-09-15 02:46:29'),
('281', '27', '7308272010', 'Desa', 'Madello', '92774', '1', '2026-09-15 02:46:29', '2026-09-15 02:46:29'),
('282', '18', '7308182003', 'Desa', 'Welado', '92755', '1', '2026-09-14 22:35:57', '2026-09-14 22:38:41'),
('283', '18', '7308182012', 'Desa', 'Manciri', '92755', '1', '2026-09-14 22:38:42', '2026-09-14 22:38:42'),
('284', '18', '7308182013', 'Desa', 'Telle', '92755', '1', '2026-09-14 22:38:42', '2026-09-14 22:38:42'),
('285', '24', '7308242004', 'Desa', 'Waempubbu', '92756', '1', '2026-11-24 16:21:08', '2026-11-24 16:21:08'),
('286', '24', '7308242005', 'Desa', 'Waemputtange', NULL, '1', '2026-11-24 16:22:13', '2026-11-24 16:22:13'),
('287', '24', '7308241015', 'Kelurahan', 'Mampotu', NULL, '1', '2026-11-24 16:24:57', '2026-11-24 16:24:57'),
('288', '19', '7308192011', 'Desa', 'Tawaroe', '92753', '1', '2026-11-25 02:53:30', '2026-11-25 02:53:30'),
('289', '19', '7308192012', 'Desa', 'Uloe', '92753', '1', '2026-11-25 02:54:18', '2026-11-25 02:54:18'),
('290', '19', '7308192013', 'Desa', 'Ujung', '92753', '1', '2026-11-25 02:55:24', '2026-11-25 02:55:24'),
('291', '19', '7308192014', 'Desa', 'Padacenga', '92753', '1', '2026-11-25 02:56:18', '2026-11-25 02:56:18'),
('292', '19', '7308192015', 'Desa', 'Lallatang', '92753', '1', '2026-11-25 02:56:54', '2026-11-25 02:56:54'),
('293', '19', '7308192016', 'Desa', 'Kampoti', '92753', '1', '2026-11-25 02:57:35', '2026-11-25 02:57:35'),
('294', '19', '7308192017', 'Desa', 'Praja Maju', '92753', '1', '2026-11-25 02:58:29', '2026-11-25 02:58:29'),
('295', '19', '7308192018', 'Desa', 'Tocina', '92753', '1', '2026-11-25 02:59:04', '2026-11-25 02:59:04');

-- --------------------------------------------------------
-- Struktur Tabel untuk `mapel`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `mapel`;
CREATE TABLE `mapel` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `jurusan_id` bigint unsigned DEFAULT NULL,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `singkatan` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kelompok` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Umum',
  `beban_jam` tinyint unsigned DEFAULT '2',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mapel_jurusan_id_foreign` (`jurusan_id`),
  KEY `mapel_school_id_is_active_index` (`school_id`,`is_active`),
  KEY `mapel_school_id_kode_index` (`school_id`,`kode`),
  KEY `mapel_school_id_kelompok_index` (`school_id`,`kelompok`),
  KEY `mapel_school_id_jurusan_id_index` (`school_id`,`jurusan_id`),
  KEY `mapel_kode_index` (`kode`),
  KEY `mapel_kelompok_index` (`kelompok`),
  KEY `mapel_is_active_index` (`is_active`),
  CONSTRAINT `mapel_jurusan_id_foreign` FOREIGN KEY (`jurusan_id`) REFERENCES `jurusan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mapel_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `mapel`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `menu_access_templates`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `menu_access_templates`;
CREATE TABLE `menu_access_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'guru',
  `menu_id` bigint unsigned DEFAULT NULL,
  `sub_menu_id` bigint unsigned DEFAULT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_access_templates_menu_id_foreign` (`menu_id`),
  KEY `menu_access_templates_sub_menu_id_foreign` (`sub_menu_id`),
  KEY `menu_access_templates_role_key_menu_id_index` (`role_key`,`menu_id`),
  KEY `menu_access_templates_role_key_sub_menu_id_index` (`role_key`,`sub_menu_id`),
  CONSTRAINT `menu_access_templates_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_access_templates_sub_menu_id_foreign` FOREIGN KEY (`sub_menu_id`) REFERENCES `sub_menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `menu_access_templates`
INSERT INTO `menu_access_templates` (`id`, `role_key`, `role_name`, `role_category`, `menu_id`, `sub_menu_id`, `can_view`, `can_create`, `can_edit`, `can_delete`, `created_at`, `updated_at`) VALUES
('2', 'wali_kelas', 'Wali Kelas', 'guru', '1', NULL, '1', '0', '0', '0', '2026-09-08 03:20:26', '2026-09-08 03:20:26'),
('3', 'wakasek_kurikulum', 'Wakil Kepala Sekolah - Kurikulum', 'guru', '1', NULL, '1', '0', '0', '0', '2026-09-08 03:20:26', '2026-09-08 03:20:26'),
('4', 'wakasek_kesiswaan', 'Wakil Kepala Sekolah - Kesiswaan', 'guru', '1', NULL, '1', '0', '0', '0', '2026-09-08 03:20:27', '2026-09-08 03:20:27'),
('6', 'murid_reguler', 'Murid Reguler (Kelas 10-11)', 'murid', '1', NULL, '1', '0', '0', '0', '2026-09-08 03:20:27', '2026-09-08 03:20:27'),
('7', 'murid_pkl', 'Murid PKL (SMK Kelas 12)', 'murid', '1', NULL, '1', '0', '0', '0', '2026-09-08 03:20:28', '2026-09-08 03:20:28'),
('82', 'admin_sekolah', 'Admin Sekolah', 'admin', '11', NULL, '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('83', 'admin_sekolah', 'Admin Sekolah', 'admin', '3', NULL, '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('84', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '5', '1', '0', '1', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('85', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '8', '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('86', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '11', '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('87', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '6', '1', '1', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('88', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '7', '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('89', 'admin_sekolah', 'Admin Sekolah', 'admin', '6', NULL, '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('90', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '10', '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('91', 'admin_sekolah', 'Admin Sekolah', 'admin', '8', NULL, '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('92', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '16', '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('93', 'admin_sekolah', 'Admin Sekolah', 'admin', NULL, '17', '1', '0', '0', '0', '2026-10-18 07:00:35', '2026-10-18 07:00:35'),
('96', 'staf_tu', 'Staf Tata Usaha', 'staf', '11', NULL, '1', '0', '0', '0', '2026-11-25 03:01:04', '2026-11-25 03:01:04'),
('114', 'guru_pengajar', 'Guru Pengajar', 'guru', '12', NULL, '1', '0', '0', '0', '2026-11-25 05:44:15', '2026-11-25 05:44:15');

-- --------------------------------------------------------
-- Struktur Tabel untuk `menus`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `module_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menus_module_id_foreign` (`module_id`),
  CONSTRAINT `menus_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `menus`
INSERT INTO `menus` (`id`, `module_id`, `name`, `route_name`, `icon`, `order`, `is_active`, `created_at`, `updated_at`) VALUES
('1', '1', 'Dashboard', 'dashboard', 'dashboard', '1', '1', '2026-09-07 07:26:19', '2026-09-23 11:42:23'),
('2', '2', 'Sistem', NULL, 'settings', '1', '1', '2026-09-07 07:26:19', '2026-09-14 20:05:14'),
('3', '3', 'Master', NULL, 'database', '1', '1', '2026-09-08 02:16:32', '2026-09-14 18:52:54'),
('4', '2', 'Backup & Restore', 'backup-restore', 'folder', '2', '1', '2026-09-08 04:28:20', '2026-09-08 04:28:20'),
('5', '1', 'Media Publik', 'tv', 'globe', '2', '1', '2026-09-14 18:48:40', '2026-09-14 18:48:40'),
('6', '3', 'Rombel & Bimbingan', NULL, 'graduation-cap', '2', '1', '2026-09-14 18:52:26', '2026-09-14 18:52:26'),
('7', '3', 'Wilayah', NULL, 'map', '3', '1', '2026-09-14 21:41:30', '2026-09-14 21:51:03'),
('8', '3', 'Konfigurasi Sekolah', NULL, 'sliders', '4', '1', '2026-09-14 22:11:37', '2026-09-14 22:11:37'),
('10', '4', 'Absensi KBM', 'absensi', 'clipboard-list', '1', '1', '2026-09-23 14:31:20', '2026-09-23 14:31:20'),
('11', '5', 'Dashboard', 'dashboard.admin', 'school', '1', '1', '2026-09-27 08:58:28', '2026-09-27 08:59:31'),
('12', '6', 'Dashboard', 'dashboard.gtk', 'briefcase', '1', '1', '2026-10-19 20:07:16', '2026-10-19 20:23:26'),
('14', '8', 'Pendaftaran Muka', 'pendaftaran_muka', 'sparkles', '1', '1', '2026-11-25 08:25:16', '2026-11-25 08:25:16'),
('15', '8', 'Absen Murid', 'absen_murid', 'menu', '2', '1', '2026-11-25 08:55:13', '2026-11-25 08:55:13');

-- --------------------------------------------------------
-- Struktur Tabel untuk `migrations`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `migrations`
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
('1', '0001_01_01_000000_create_users_table', '1'),
('2', '0001_01_01_000001_create_cache_table', '1'),
('3', '0001_01_01_000002_create_jobs_table', '1'),
('4', '2026_09_05_000001_add_system_columns_to_users_table', '1'),
('5', '2026_09_05_030250_create_modules_table', '1'),
('6', '2026_09_05_030258_create_menus_table', '1'),
('7', '2026_09_05_030259_create_sub_menus_table', '1'),
('8', '2026_09_06_011322_create_user_menu_permissions_table', '2'),
('9', '2026_09_06_011336_create_menu_access_templates_table', '2'),
('10', '2026_09_13_080000_create_schools_table', '3'),
('11', '2026_09_13_052346_create_provinsi_table', '4'),
('12', '2026_09_13_062026_create_kabupaten_table', '5'),
('13', '2026_09_13_070000_create_kecamatan_table', '6'),
('14', '2026_09_13_074142_create_kelurahan_table', '7'),
('15', '2026_09_13_173204_create_kalender_akademik_table', '8'),
('18', '2026_09_13_210000_create_tahun_ajaran_table', '9'),
('19', '2026_09_13_210100_create_semester_table', '9'),
('20', '2026_09_13_220000_create_jurusan_table', '10'),
('21', '2026_09_26_104120_add_school_id_and_nullable_email_to_users_table', '11'),
('22', '2026_09_26_104134_update_user_type_siswa_to_murid', '11'),
('25', '2026_10_04_221656_create_gtks_table', '12'),
('26', '2026_10_24_144748_create_tingkatan_table', '13'),
('27', '2026_10_29_120945_create_mapel_table', '14'),
('28', '2026_10_29_132840_create_kelas_table', '15'),
('29', '2026_10_29_155708_create_murids_table', '16'),
('31', '2026_11_01_000001_create_referensi_table', '17'),
('32', '2026_11_25_083804_create_murid_face_profiles_table', '18'),
('33', '2026_11_25_085651_create_absensi_murids_table', '19');

-- --------------------------------------------------------
-- Struktur Tabel untuk `modules`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `modules`
INSERT INTO `modules` (`id`, `name`, `order`, `is_active`, `created_at`, `updated_at`) VALUES
('1', 'NAVIGASI UTAMA', '1', '1', '2026-09-07 07:26:19', '2026-09-14 20:05:13'),
('2', 'PENGATURAN SISTEM', '7', '1', '2026-09-07 07:26:19', '2026-11-25 08:22:52'),
('3', 'ADMINISTRASI', '4', '1', '2026-09-08 02:15:41', '2026-10-19 20:06:40'),
('4', 'AKADEMIK', '5', '1', '2026-09-23 14:30:03', '2026-10-19 20:06:40'),
('5', 'HALAMAN ADMIN', '2', '1', '2026-09-27 08:56:29', '2026-09-27 09:10:10'),
('6', 'HALAMAN GTK', '3', '1', '2026-10-19 20:06:40', '2026-10-19 20:06:40'),
('8', 'FACE RECOGNITION', '6', '1', '2026-11-25 08:22:52', '2026-11-25 08:22:52');

-- --------------------------------------------------------
-- Struktur Tabel untuk `murid_face_profiles`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `murid_face_profiles`;
CREATE TABLE `murid_face_profiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `murid_id` bigint unsigned NOT NULL,
  `label` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Tampak Depan',
  `foto_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `face_descriptor` json NOT NULL,
  `confidence` decimal(5,4) DEFAULT NULL,
  `model_version` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'vladmandic-face-api-tiny-128d',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `registered_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `murid_face_profiles_murid_id_foreign` (`murid_id`),
  KEY `murid_face_profiles_registered_by_foreign` (`registered_by`),
  KEY `murid_face_profiles_school_murid_active_idx` (`school_id`,`murid_id`,`is_active`),
  KEY `murid_face_profiles_is_active_index` (`is_active`),
  CONSTRAINT `murid_face_profiles_murid_id_foreign` FOREIGN KEY (`murid_id`) REFERENCES `murids` (`id`) ON DELETE CASCADE,
  CONSTRAINT `murid_face_profiles_registered_by_foreign` FOREIGN KEY (`registered_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `murid_face_profiles_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `murid_face_profiles`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `murids`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `murids`;
CREATE TABLE `murids` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `kelas_id` bigint unsigned DEFAULT NULL,
  `angkatan` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nisn` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nis` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nik` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_hp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provinsi_id` bigint unsigned DEFAULT NULL,
  `kabupaten_id` bigint unsigned DEFAULT NULL,
  `kecamatan_id` bigint unsigned DEFAULT NULL,
  `kelurahan_id` bigint unsigned DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `nama_ayah` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_ibu` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_wali` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_hp_ortu` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktif',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `murids_school_id_foreign` (`school_id`),
  KEY `murids_user_id_foreign` (`user_id`),
  KEY `murids_kelas_id_foreign` (`kelas_id`),
  KEY `murids_provinsi_id_foreign` (`provinsi_id`),
  KEY `murids_kabupaten_id_foreign` (`kabupaten_id`),
  KEY `murids_kecamatan_id_foreign` (`kecamatan_id`),
  KEY `murids_kelurahan_id_foreign` (`kelurahan_id`),
  KEY `murids_angkatan_index` (`angkatan`),
  KEY `murids_nisn_index` (`nisn`),
  KEY `murids_nis_index` (`nis`),
  KEY `murids_nik_index` (`nik`),
  KEY `murids_nama_lengkap_index` (`nama_lengkap`),
  KEY `murids_jenis_kelamin_index` (`jenis_kelamin`),
  KEY `murids_status_index` (`status`),
  KEY `murids_is_active_index` (`is_active`),
  CONSTRAINT `murids_kabupaten_id_foreign` FOREIGN KEY (`kabupaten_id`) REFERENCES `kabupaten` (`id`) ON DELETE SET NULL,
  CONSTRAINT `murids_kecamatan_id_foreign` FOREIGN KEY (`kecamatan_id`) REFERENCES `kecamatan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `murids_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `murids_kelurahan_id_foreign` FOREIGN KEY (`kelurahan_id`) REFERENCES `kelurahan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `murids_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsi` (`id`) ON DELETE SET NULL,
  CONSTRAINT `murids_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE,
  CONSTRAINT `murids_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `murids`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `password_reset_tokens`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `password_reset_tokens`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `provinsi`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `provinsi`;
CREATE TABLE `provinsi` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kode` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provinsi_kode_unique` (`kode`),
  KEY `provinsi_nama_index` (`nama`),
  KEY `provinsi_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `provinsi`
INSERT INTO `provinsi` (`id`, `kode`, `nama`, `status`, `created_at`, `updated_at`) VALUES
('2', '12', 'Sumatera Utara', '1', '2026-09-15 00:24:52', '2026-09-15 00:24:52'),
('3', '13', 'Sumatera Barat', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('4', '14', 'Riau', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('5', '15', 'Jambi', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('6', '16', 'Sumatera Selatan', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('7', '17', 'Bengkulu', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('8', '18', 'Lampung', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('9', '19', 'Kepulauan Bangka Belitung', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('10', '21', 'Kepulauan Riau', '1', '2026-09-15 00:24:53', '2026-09-15 00:24:53'),
('11', '31', 'DKI Jakarta', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('12', '32', 'Jawa Barat', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('13', '33', 'Jawa Tengah', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('14', '34', 'DI Yogyakarta', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('15', '35', 'Jawa Timur', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('16', '36', 'Banten', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('17', '51', 'Bali', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('18', '52', 'Nusa Tenggara Barat', '1', '2026-09-15 00:24:54', '2026-09-15 00:24:54'),
('19', '53', 'Nusa Tenggara Timur', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('20', '61', 'Kalimantan Barat', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('21', '62', 'Kalimantan Tengah', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('22', '63', 'Kalimantan Selatan', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('23', '64', 'Kalimantan Timur', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('24', '65', 'Kalimantan Utara', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('25', '71', 'Sulawesi Utara', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('26', '72', 'Sulawesi Tengah', '1', '2026-09-15 00:24:55', '2026-09-15 00:24:55'),
('27', '73', 'Sulawesi Selatan', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('28', '74', 'Sulawesi Tenggara', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('29', '75', 'Gorontalo', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('30', '76', 'Sulawesi Barat', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('31', '81', 'Maluku', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('32', '82', 'Maluku Utara', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('33', '91', 'Papua', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('34', '92', 'Papua Barat', '1', '2026-09-15 00:24:56', '2026-09-15 00:24:56'),
('35', '93', 'Papua Selatan', '1', '2026-09-15 00:24:57', '2026-09-15 00:24:57'),
('36', '94', 'Papua Tengah', '1', '2026-09-15 00:24:57', '2026-09-15 00:24:57'),
('37', '95', 'Papua Pegunungan', '1', '2026-09-15 00:24:57', '2026-09-15 00:24:57'),
('38', '96', 'Papua Barat Daya', '1', '2026-09-15 00:24:57', '2026-09-15 00:24:57'),
('39', '11', 'Aceh', '1', '2026-09-30 12:13:10', '2026-09-30 12:13:10');

-- --------------------------------------------------------
-- Struktur Tabel untuk `referensi`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `referensi`;
CREATE TABLE `referensi` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `referensi_id` bigint unsigned DEFAULT NULL,
  `nama` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `extra_attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referensi_referensi_id_foreign` (`referensi_id`),
  KEY `referensi_kode_index` (`kode`),
  KEY `referensi_is_active_index` (`is_active`),
  CONSTRAINT `referensi_referensi_id_foreign` FOREIGN KEY (`referensi_id`) REFERENCES `referensi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referensi_chk_1` CHECK (json_valid(`extra_attributes`))
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `referensi`
INSERT INTO `referensi` (`id`, `referensi_id`, `nama`, `kode`, `is_active`, `is_system`, `extra_attributes`, `created_at`, `updated_at`) VALUES
('1', NULL, 'Tipe Sekolah', 'school_type', '1', '1', NULL, '2026-11-01 20:40:49', '2026-11-01 20:40:49'),
('2', '1', 'SMA (Sekolah Menengah Atas)', 'SMA', '1', '1', '{\"is_madrasah\":false}', '2026-11-01 20:40:49', '2026-11-01 20:40:49'),
('3', '1', 'SMK (Sekolah Menengah Kejuruan)', 'SMK', '1', '1', '{\"is_madrasah\":false}', '2026-11-01 20:40:49', '2026-11-01 20:40:49'),
('4', '1', 'MA (Madrasah Aliyah)', 'MA', '1', '1', '{\"is_madrasah\":true}', '2026-11-01 20:40:50', '2026-11-01 20:40:50'),
('5', '1', 'MAK (Madrasah Aliyah Kejuruan)', 'MAK', '1', '1', '{\"is_madrasah\":true}', '2026-11-01 20:40:51', '2026-11-01 20:40:51'),
('6', '1', 'SMP (Sekolah Menengah Pertama)', 'SMP', '1', '1', '{\"is_madrasah\":false}', '2026-11-01 20:40:51', '2026-11-01 20:40:51'),
('7', '1', 'MTs (Madrasah Tsanawiyah)', 'MTs', '1', '1', '{\"is_madrasah\":true}', '2026-11-01 20:40:53', '2026-11-01 20:40:53'),
('8', '1', 'SD (Sekolah Dasar)', 'SD', '1', '1', '{\"is_madrasah\":false}', '2026-11-01 20:40:53', '2026-11-01 20:40:53'),
('9', '1', 'MI (Madrasah Ibtidaiyah)', 'MI', '1', '1', '{\"is_madrasah\":true}', '2026-11-01 20:40:53', '2026-11-01 20:40:53'),
('10', NULL, 'Akreditasi Sekolah', 'accreditation', '1', '1', NULL, '2026-11-01 20:40:54', '2026-11-01 20:40:54'),
('11', '10', 'A (Unggul)', 'A', '1', '1', NULL, '2026-11-01 20:40:54', '2026-11-01 20:40:54'),
('12', '10', 'B (Baik)', 'B', '1', '1', NULL, '2026-11-01 20:41:00', '2026-11-01 20:41:00'),
('13', '10', 'C (Cukup)', 'C', '1', '1', NULL, '2026-11-01 20:41:00', '2026-11-01 20:41:00'),
('14', '10', 'Belum Terakreditasi', 'Belum', '1', '1', NULL, '2026-11-01 20:41:02', '2026-11-01 20:41:02');

-- --------------------------------------------------------
-- Struktur Tabel untuk `schools`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `schools`;
CREATE TABLE `schools` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `npsn` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nss` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accreditation` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provinsi_id` bigint unsigned DEFAULT NULL,
  `kabupaten_id` bigint unsigned DEFAULT NULL,
  `kecamatan_id` bigint unsigned DEFAULT NULL,
  `kelurahan_id` bigint unsigned DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `village` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `principal_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `principal_nip` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foundation_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schools_npsn_index` (`npsn`),
  KEY `schools_school_type_index` (`school_type`),
  KEY `schools_is_active_index` (`is_active`),
  KEY `schools_provinsi_id_foreign` (`provinsi_id`),
  KEY `schools_kabupaten_id_foreign` (`kabupaten_id`),
  KEY `schools_kecamatan_id_foreign` (`kecamatan_id`),
  KEY `schools_kelurahan_id_foreign` (`kelurahan_id`),
  CONSTRAINT `schools_kabupaten_id_foreign` FOREIGN KEY (`kabupaten_id`) REFERENCES `kabupaten` (`id`) ON DELETE SET NULL,
  CONSTRAINT `schools_kecamatan_id_foreign` FOREIGN KEY (`kecamatan_id`) REFERENCES `kecamatan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `schools_kelurahan_id_foreign` FOREIGN KEY (`kelurahan_id`) REFERENCES `kelurahan` (`id`) ON DELETE SET NULL,
  CONSTRAINT `schools_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsi` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `schools`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `semester`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `semester`;
CREATE TABLE `semester` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tahun_ajaran_id` bigint unsigned NOT NULL,
  `semester` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `semester_tahun_ajaran_id_semester_index` (`tahun_ajaran_id`,`semester`),
  KEY `semester_tahun_ajaran_id_is_active_index` (`tahun_ajaran_id`,`is_active`),
  KEY `semester_semester_index` (`semester`),
  KEY `semester_tanggal_mulai_index` (`tanggal_mulai`),
  KEY `semester_tanggal_selesai_index` (`tanggal_selesai`),
  KEY `semester_is_active_index` (`is_active`),
  CONSTRAINT `semester_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajaran` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `semester`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `sessions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `sessions`
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('DukdJGIDY45kwHWiYHdSJMpfoJLq0lrbtVQr6yZZ', '1', '172.20.0.1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'eyJfdG9rZW4iOiJHNHM1OEtUVFF3cnJNeVA2Ulh3Nk9jeTRSa29sOWV4U0ZYNWJtajRnIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoxLCJwYXNzd29yZF9oYXNoX3dlYiI6IjZmY2E4MmMxY2JhMTU3MWNiM2M2YTI1NDkzODE5NDI3YWE3MjJhMjYyZGU0YTk5ODk3ZGUyN2Y5YzgxZWJjOWUifQ==', '1795576411');

-- --------------------------------------------------------
-- Struktur Tabel untuk `sub_menus`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `sub_menus`;
CREATE TABLE `sub_menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_menus_menu_id_foreign` (`menu_id`),
  CONSTRAINT `sub_menus_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `sub_menus`
INSERT INTO `sub_menus` (`id`, `menu_id`, `name`, `route_name`, `order`, `is_active`, `created_at`, `updated_at`) VALUES
('1', '2', 'Modul', 'system.modules.index', '1', '1', '2026-09-07 07:26:20', '2026-09-14 20:05:14'),
('2', '2', 'Menu', 'system.menus.index', '2', '1', '2026-09-07 07:26:20', '2026-09-14 20:05:14'),
('3', '2', 'Sub-Menu', 'system.sub-menus.index', '3', '1', '2026-09-07 07:26:20', '2026-09-14 20:05:14'),
('4', '2', 'User', 'sistem.user', '4', '1', '2026-09-08 01:54:27', '2026-09-14 17:32:36'),
('5', '3', 'Data Sekolah', 'master.data-sekolah', '1', '1', '2026-09-08 02:18:26', '2026-09-08 02:18:26'),
('6', '3', 'Data Pendidik & Tendik (gtk)', 'master.data-gtk', '5', '1', '2026-09-14 18:05:21', '2026-09-15 00:11:37'),
('7', '3', 'Data Murid', 'master.data-murid', '6', '1', '2026-09-14 18:07:10', '2026-09-15 00:11:46'),
('8', '3', 'Data Tingkatan', 'master.data-tingkatan', '2', '1', '2026-09-14 19:40:56', '2026-09-15 00:10:44'),
('9', '3', 'Data Jurusan', 'master.data-jurusan', '3', '1', '2026-09-14 19:41:33', '2026-09-15 00:11:08'),
('10', '6', 'Data Kelas', 'rombel.kelas', '3', '1', '2026-09-14 19:42:03', '2026-09-14 19:42:03'),
('11', '3', 'Data Mata Pelajaran', 'master.data-mapel', '4', '1', '2026-09-14 21:39:08', '2026-09-15 00:11:25'),
('12', '7', 'Provinsi', 'wilayah.provinsi', '1', '1', '2026-09-14 21:41:57', '2026-09-14 21:41:57'),
('13', '7', 'Kabupaten', 'wilayah.kabupaten', '2', '1', '2026-09-14 21:42:18', '2026-09-14 21:42:18'),
('14', '7', 'Kecamatan', 'wilayah.kecamatan', '3', '1', '2026-09-14 21:42:40', '2026-09-14 21:43:13'),
('15', '7', 'Kelurahan', 'wilayah.kelurahan', '4', '1', '2026-09-14 21:43:29', '2026-09-14 21:43:29'),
('16', '8', 'Tahun Ajaran', 'konfigurasi-sekolah.tahun-ajaran', '1', '1', '2026-09-14 22:12:57', '2026-09-14 22:12:57'),
('17', '8', 'Kalender Akademik', 'konfigurasi-sekolah.kalender-akademik', '2', '1', '2026-09-14 22:13:32', '2026-09-14 22:13:32'),
('18', '2', 'Referensi', 'system.referensi', '5', '1', '2026-11-01 20:04:18', '2026-11-01 20:04:18');

-- --------------------------------------------------------
-- Struktur Tabel untuk `tahun_ajaran`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tahun_ajaran`;
CREATE TABLE `tahun_ajaran` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `tahun` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tahun_ajaran_school_id_is_active_index` (`school_id`,`is_active`),
  KEY `tahun_ajaran_school_id_tahun_index` (`school_id`,`tahun`),
  KEY `tahun_ajaran_tahun_index` (`tahun`),
  KEY `tahun_ajaran_is_active_index` (`is_active`),
  CONSTRAINT `tahun_ajaran_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `tahun_ajaran`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `tingkatan`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tingkatan`;
CREATE TABLE `tingkatan` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned NOT NULL,
  `kode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tingkat_angka` tinyint unsigned NOT NULL,
  `fase` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tingkatan_school_id_kode_unique` (`school_id`,`kode`),
  UNIQUE KEY `tingkatan_school_id_tingkat_angka_unique` (`school_id`,`tingkat_angka`),
  KEY `tingkatan_school_id_is_active_index` (`school_id`,`is_active`),
  KEY `tingkatan_kode_index` (`kode`),
  KEY `tingkatan_tingkat_angka_index` (`tingkat_angka`),
  KEY `tingkatan_is_active_index` (`is_active`),
  CONSTRAINT `tingkatan_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `tingkatan`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `user_menu_permissions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_menu_permissions`;
CREATE TABLE `user_menu_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `menu_id` bigint unsigned DEFAULT NULL,
  `sub_menu_id` bigint unsigned DEFAULT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_menu_permissions_menu_id_foreign` (`menu_id`),
  KEY `user_menu_permissions_sub_menu_id_foreign` (`sub_menu_id`),
  KEY `user_menu_permissions_user_id_menu_id_index` (`user_id`,`menu_id`),
  KEY `user_menu_permissions_user_id_sub_menu_id_index` (`user_id`,`sub_menu_id`),
  CONSTRAINT `user_menu_permissions_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_menu_permissions_sub_menu_id_foreign` FOREIGN KEY (`sub_menu_id`) REFERENCES `sub_menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_menu_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=574 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `user_menu_permissions`
-- (Tidak ada data)

-- --------------------------------------------------------
-- Struktur Tabel untuk `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'super_admin',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `avatar_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_user_type_index` (`user_type`),
  KEY `users_is_active_index` (`is_active`),
  KEY `users_school_id_user_type_index` (`school_id`,`user_type`),
  CONSTRAINT `users_school_id_foreign` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data untuk Tabel `users`
INSERT INTO `users` (`id`, `school_id`, `name`, `username`, `email`, `email_verified_at`, `password`, `user_type`, `is_active`, `avatar_path`, `remember_token`, `created_at`, `updated_at`) VALUES
('1', NULL, 'Super Administrator', 'superadmin', 'superadmin@infora.test', NULL, '$2y$12$GK8JQ1.Zgk98WdP.Hl5Jwuz.vBNf1pc.f0Tos4VGqtg.03fKcZlw6', 'super_admin', '1', NULL, NULL, '2026-09-07 07:26:18', '2026-09-07 07:26:18');

SET FOREIGN_KEY_CHECKS=1;
-- ===================== SELESAI ======================
